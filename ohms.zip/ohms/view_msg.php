<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_member.php') ;
else
{
$mid=$_SESSION['mid'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id=$mid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mname=$row['mem_name'];
		//$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>

<html>
<head>
<title>Message</title>
<script>
function myFunction() {
    window.print();
}
</script>
</head>
<body>
<?php
$not_id=$_POST["not_id"];

include("connec.php");	//database parameters

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
	
$sql = "SELECT * FROM notice_board WHERE not_id=$not_id";
$result = mysqli_query($conn, $sql);				

if (mysqli_num_rows($result) > 0) {
	// output data of each row						
	while($row = mysqli_fetch_assoc($result)) {		
		$not_id=$row["not_id"];
		$sender_type=$row["sender_type"];
		$send_mem_id=$row["send_mem_id"];
		$sub=$row["sub"];
		$body=$row["body"];
		$date=$row["date"];
		$time=$row["time"];
		$recv_mem_id=$row["recv_mem_id"];
								
		if($sender_type=="admin")
			$mem_name="Admin";
			$atype="admin";
		if($sender_type=="member")
		{
			$sql2 = "SELECT * FROM member_master where mem_id=$send_mem_id";
			$result2 = $conn->query($sql2);

			if ($result2->num_rows > 0) {
				// output data of each row
				while($row = $result2->fetch_assoc()) {
					$mem_name=$row['mem_name'];
					$atype=$row['atype'];
				}
			} else {
				//echo "0 results";
			}
		}					
	}
} else {
	//echo "<center>No member to display</center>";
}

mysqli_close($conn);
?>

<table border="1" align="center" width="50%">
<tr><td colspan="2"><?php include("logo.html");	?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font></td></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><th colspan="2" align="center">MESSAGE</th></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><td width="25%"><b>Subject</b></td><td width="25%"><?php echo $sub;?></td></tr>
<tr><td width="25%"><b>From</b></td><td width="25%"><?php echo $mem_name." (".$atype.")";?></td></tr>
<tr><td width="25%"><b>On</b></td><td width="25%"><?php echo $date." ".$time;?></td></tr>
<tr><td width="25%"><b>To</b></td><td width="25%"><?php if($recv_mem_id!=0){echo $mname;} else{echo "General";} ?></td></tr>
<tr><td colspan="2"><b>Body</b></td></tr>
<tr><td colspan="2"><?php echo $body;?></td></tr>
</table>
<p></p>
<hr>
<center><button onclick="myFunction()">Print</button></center>
<p></p>
<center><a href="mem_home.php">Home</a></center>
<p></p>
<hr>

<?php
	echo "<center>";
	include("footer.html");
	echo "</center>";
?>
</body>
</html>