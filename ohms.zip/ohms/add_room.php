<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Room Management | Add Room</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li><a href="room_info.php"><i class="glyphicon glyphicon-home"> </i>Room Information</a></li>
					<li><a class="active" href="add_room.php"><i class="glyphicon glyphicon-home"> </i>Add<br>Room</a></li>					
					<li><a href="update_room.php"><i class="glyphicon glyphicon-home"> </i>Update Room</a></li>
					<li><a href="del_room.php"><i class="glyphicon glyphicon-home"> </i>Delete Room</a></li>
					<li><a href="room_mem.php"><i class="glyphicon glyphicon-user"> </i>Room Members</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Room Management</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Add Room</h3>					
				</div>
				 <form action="add_room.php" method="post">					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							Room No.:<br>
							<input type="text" name="room_no" id="room_no" style="text-transform:uppercase">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Building:<br>
							<select id="building" name="building">
								<option value="select">-- Select --</option>
								<option value="Boys Hostel">Boys Hostel</option>
								<option value="Girls Hostel">Girls Hostel</option>
								<option value="Gents Hostel">Gents Hostel</option>
								<option value="Ladies Hostel">Ladies Hostel</option>
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>										
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							Total Beds:<br>
							<input type="number" name="total_beds" id="total_beds">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Beds Taken:<br>
							<input type="number" name="beds_taken" value="0" id="beds_taken">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<center>
					<div class="send">
						<input type="submit" id="add" name="add" value="Add">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->

<!--add room start here-->
<?php
		
	if(isset($_POST['add'])){
	
	include("connec.php");	//database parameters

	$room_no=$_POST["room_no"];
	$building=$_POST["building"];
	$beds_taken=$_POST["beds_taken"];
	$total_beds=$_POST["total_beds"];

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "INSERT INTO room VALUES ('$room_no', '$building', '$beds_taken', '$total_beds')";	

	if ($conn->query($sql) === TRUE) {
			echo "<p align='center'>room added successfully.....</p>";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();	
	}
?>
<!--add room end here-->

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>