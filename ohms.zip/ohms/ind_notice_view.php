<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
else
{
$mid=$_POST['mem_id'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id=$mid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mname=$row['mem_name'];
		//$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>


<html>
<head>
<title>OHMS | Admin | Generate Notices | Individual Notices | Sent Messages</title>
</head>
<body>
<table border="0" align="center" width="100%">
<tr><td align="center"><hr><?php include("logo.html");?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font><hr></td></tr>
<tr><td><b>Member ID:</b> <?php echo $mid;?></td></tr>
<tr><td><b>Member Name:</b> <?php echo $mname;?></td></tr>
<tr><th align="center"><hr>SENT MESSAGES<hr></th></tr>
</table>

<table border="1" align="center" width="100%">									
<tr>																
<td align="center" width="20%"><b>Subject</b></td>
<td width="20%"><center><b>Body</b></center></td>
<td align="center" width="20%"><b>Date</b></td>
<td align="center" width="20%"><b>Time</b></td>
<td width="20%"></td>
</tr>

				<?php
				
				//notices
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM notice_board WHERE not_id<>0 AND recv_mem_id=$mid ORDER BY date DESC, STR_TO_DATE(time, '%l:%i %p') DESC";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$not_id=$row["not_id"];						
						$sub=$row["sub"];
						$body=$row["body"];
						$date=$row["date"];
						$time=$row["time"];
						
						echo "<tr><td><center>".$sub."</center></td><td><center>".$body."</center></td><td><center>".$date."</center></td><td><center>".$time."</center></td><td><center><form action='ind_notice_del.php' method='post'><input type='hidden' name='not_id' value=".$not_id."><input type='submit' id='del' name='del' value='Delete'></form></center></td></tr>";
					}
				}else {
					//echo "<center>Nothing to display</center>";
				}

				mysqli_close($conn);
	
				?>

</table>

<p></p>
<center><a href="ind_notice.php">Back</a></center>
<p></p>
<hr>

<?php
	echo "<center>";
	include("footer.html");
	echo "</center>";
?>
</body>
</html>