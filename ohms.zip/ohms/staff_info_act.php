<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$fname=basename(__FILE__);
$_SESSION["fname"] = $fname;

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Staff Portal | Staff Information | Active Staffs</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<link rel="stylesheet" href="css/style_button.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<!--<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #01BF07;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 20px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button:hover {
  padding-right: 40px;
   color: #FFFFFF;
   font-weight:bold;
  
}

.button:hover 
  opacity: 1;
  right: 0;
}
</style>-->

</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
				<?php
					include("logo.html");
				?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li><a href="staff_info_inact.php"><i class="glyphicon glyphicon-user"> </i>Inactive Staffs</a></li>										
					<li><a class="active" href="staff_info_act.php"><i class="glyphicon glyphicon-user"> </i>Active Staffs</a></li>
					<li><a href="staff_info_deact.php"><i class="glyphicon glyphicon-user"> </i>Deactive Staffs</a></li>
					<li><a href="staff_info_left.php"><i class="glyphicon glyphicon-user"> </i>Staffs<br>Left</a></li>					
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <a href="staff_port.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-user"></span> Staff Portal</a>/ <span class="glyphicon glyphicon-user"></span> Staff Information</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>
  </div>
</div>
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Active Staffs</h2>
				<p> </p>
			</div>
			
			
			
			
			
			
			<div class="table-users" style="width:100%;">
   
   
			<table cellspacing="0" width="100%">
			<tr>
			<th width="10%"></th>
			<th width="5%"><center><b>Member ID</b></center></th>
			<th width="20%"><center><b>Name</b></center></th>
			<th width="10%"><center><b>Phone No.</b></center></th>
			<th width="10%"><center><b>Occupation</b></center></th>
			<th width="5%"><center><b>Gender</b></center></th>
			<th width="5%"><center><b>Room No.</b></center></th>
			<th width="15%"><center><b>Building</b></center></th>
			<th width="10%"><center><b>Status</b></center></th>
			<th width="5%"></th>
			<th width="5%"></th>
			</tr>
			<?php
				
				//student information
						
				include("connec.php");	//database connection
	
				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$sql = "SELECT * FROM member_master where atype='Staff' and app_status='APPROVED' and mem_status='ACTIVE'";
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$mem_id=$row["mem_id"];
								$mem_name=$row["mem_name"];
								$phno=$row["phno"];
								$occup=$row["occup"];
								$gender=$row["gender"];
								$room_no=$row["room_no"];
								$pic=$row["pic"];
								$mem_status=$row["mem_status"];
								
								$sql2 = "SELECT * FROM room where room_no='$room_no'";
								$result2 = mysqli_query($conn, $sql2);
				
								if (mysqli_num_rows($result2) > 0) {
									// output data of each row						
									while($row = mysqli_fetch_assoc($result2)) {								
										$building=$row["building"];
									}
								} else {
									//echo "";
								}
								
								echo "<tr><td><img src='uploads/".$pic."'/></td><td>".$mem_id."</td><td>".$mem_name."</td><td>".$phno."</td><td>".$occup."</td><td>".$gender."</td><td style='text-transform:uppercase'>".$room_no."</td><td>".$building."</td><td>".$mem_status."</td><td><form action='mem_prof_admin.php' method='post'><input type='hidden' name='mem_id' value=".$mem_id."><input type='submit' id='submit' class='button' style='vertical-align:middle' name='submit' value='view profile'></form></td><td><form action='mem_status.php' method='post'><input type='hidden' name='mem_id' value=".$mem_id."><input type='submit' id='submit2' class='button2' style='vertical-align:middle' name='submit2' value='Deactivate'></form></td></tr>";									
						}
				} else {
					//echo "<center>No member to display</center>";
				}

				mysqli_close($conn);			
			?>

      
      
   </table>
</div>
			
			
			
		</div>
	</div>
</div>
<!--about end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>