<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Successful Registration</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>		
</div>	
<!--banner end here-->

<?php
	$dor=$_POST["dor"];
	$mem_id=$_POST["mem_id"];
	$mem_name=$_POST["mem_name"];
	$addr=$_POST["addr"];
	$phno=$_POST["phno"];
	$email=$_POST["email"];	
	$dob=$_POST["dob"];
	$gname=$_POST["gname"];	
	$gphno=$_POST["gphno"];
	$atype=$_POST["atype"];	
	$occup=$_POST["occup"];
	$gender=$_POST["gender"];
	$room_no=$_POST["room_no"];
	//$mem_uname=$_POST["mem_uname"];
	//$mem_pass=$_POST["mem_pass"];
	
	$_SESSION["dor"]=$dor;
	$_SESSION["mem_id"]=$mem_id;
	$_SESSION["mem_name"]=$mem_name;
	$_SESSION["addr"]=$addr;
	$_SESSION["phno"]=$phno;
	$_SESSION["email"]=$email;
	$_SESSION["dob"]=$dob;
	$_SESSION["gname"]=$gname;
	$_SESSION["gphno"]=$gphno;
	$_SESSION["atype"]=$atype;
	$_SESSION["occup"]=$occup;
	$_SESSION["gender"]=$gender;
	$_SESSION["room_no"]=$room_no;
	//$_SESSION["mem_uname"]=$mem_uname;
	//$_SESSION["mem_pass"]=$mem_pass;
	
	$otp=rand(1000,9999);
?>

<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">				
				<p> </p>
			</div>
			<form action="reg_success.php" method="post">
			<div class="contact-grid">
				<div class="col-md-4 contact-us">
					<!-- <input type="text" name="Name" placeholder="Name">-->							
				</div>
				<div class="col-md-4 contact-us">
					A 4 digit OTP has been send to your registered mobile...<br>
					<b>Enter your OTP:</b>
					<?php echo $otp; ?>
					<input type="text" id="otp" name="otp">
					<input type="hidden" id="otp2" name="otp2" value="<?php echo $otp; ?>">
				</div>
				<div class="col-md-4 contact-us">
					<!-- <input type="text" name="email" placeholder="Email">-->
				</div>
				<div class="clearfix"> </div>
				<center>
				<div class="send">
					<input type="submit" id="submit" name="submit" value="Submit">
				</div>
				</center>
			</div>
			</form>
		</div>
	</div>
</div>

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>