<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Registration Form</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
<!--<script type="text/javascript" src="js/test.js"></script>-->
<script type="text/javascript">
function jsFunction(atype,gender)
{
	document.getElementById("occup").options.length = 0;
	
	switch(atype)
    {
        case "Student" :
            document.getElementById("occup").options[0]=new Option("--Select--");
			document.getElementById("occup").options[1]=new Option("DIPLOMA");
            document.getElementById("occup").options[2]=new Option("B.TECH");
            document.getElementById("occup").options[3]=new Option("MBA");
			
			if(gender=="Male")
			{
				document.getElementById("building").value="Boys Hostel";
				document.getElementById("building").focus();
				
				document.getElementById("building2").value="Boys Hostel";			
			}
			if(gender=="Female")
			{
				document.getElementById("building").value="Girls Hostel";
				document.getElementById("building").focus();
				
				document.getElementById("building2").value="Girls Hostel";			
			}
            
			break;
			
        case "Staff" :
            document.getElementById("occup").options[0]=new Option("--Select--");
			document.getElementById("occup").options[1]=new Option("TEACHING STAFF");
            document.getElementById("occup").options[2]=new Option("NON-TEACHING STAFF");
            
			if(gender=="Male")
			{
				document.getElementById("building").value="Gents Hostel";
				document.getElementById("building").focus();
				
				document.getElementById("building2").value="Gents Hostel";			
			}
			if(gender=="Female")
			{
				document.getElementById("building").value="Ladies Hostel";
				document.getElementById("building").focus();
				
				document.getElementById("building2").value="Ladies Hostel";			
			}
			
            break;
    }
}

function jsFunction3(atype,gender)
{
	if(atype=="Student")
	{
		if(gender=="Male")
		{
			document.getElementById("building").value="Boys Hostel";
			document.getElementById("building").focus();
			
			document.getElementById("building2").value="Boys Hostel";			
		}
		if(gender=="Female")
		{
			document.getElementById("building").value="Girls Hostel";
			document.getElementById("building").focus();
			
			document.getElementById("building2").value="Girls Hostel";			
		}
	}
	if(atype=="Staff")
	{
		if(gender=="Male")
		{
			document.getElementById("building").value="Gents Hostel";
			document.getElementById("building").focus();
			
			document.getElementById("building2").value="Gents Hostel";			
		}
		if(gender=="Female")
		{
			document.getElementById("building").value="Ladies Hostel";
			document.getElementById("building").focus();
			
			document.getElementById("building2").value="Ladies Hostel";			
		}
	}   
}

function showRooms(str) {	
	if (str.length == 0) { 
        document.getElementById("room_no").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("room_no").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "getroom.php?building=" + str, true);
        xmlhttp.send();
    }
	
	document.getElementById("room_no").focus();
}
</script>
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a class="active" href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->

<!-- auto number generation starts -->		
		<?php				
		include("connec.php");	//database parameters
				
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM member_master";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$b = $row["mem_id"];
				$c=intval($b);
				$r=$c+1;

				//echo $d;
			}
		}
				
		$conn->close();
		?>
<!-- auto number generation ends -->

<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Registration Form</h3>					
				</div>
				 <form action="OTP.php" method="post">													
					<input type="hidden" id="mem_id" name="mem_id" value="<?php echo $r; ?>">						
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="hidden" id="dor" name="dor" value="<?php echo date("d/m/Y"); ?>">						
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter your name:</font><br>
							<input type="text" id="mem_name" name="mem_name" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter your address:</font><br>
							<textarea id="addr" name="addr" required></textarea>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter your contact no.:</font><br>
							<input type="number" id="phno" name="phno" minlength="10" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter your email id:</font><br>
							<input type="email" id="email" name="email" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Date of Birth:</font><br>
							<input type="date" id="dob" name="dob" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Guardian's Name:</font><br>
							<input type="text" id="gname" name="gname" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Guardian's phone no.:</font><br>
							<input type="number" id="gphno" name="gphno" minlength="10" required>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Applicant's Type:</font><br>
							<select id="atype" name="atype" onchange="jsFunction(this.options[this.selectedIndex].value,document.getElementById('gender').options[document.getElementById('gender').selectedIndex].value)" required>
								<option value="" selected>-- Select --</option>
								<option value="Student">Student</option>
								<option value="Staff">Staff</option>	
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Occupation:</font><br>
							<select id="occup" name="occup" required>
																
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Gender:</font><br>							
							<select id="gender" name="gender" onchange="jsFunction3(document.getElementById('atype').options[document.getElementById('atype').selectedIndex].value,this.options[this.selectedIndex].value)" required>
								<option value="" selected>-- Select --</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Building:</font><br>							
							<input type="text" id="building" name="building" onfocus="showRooms(this.value)" required>														
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<input type="hidden" id="building2" name="building2">
					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Room no.:</font><br>
							<select id="room_no" name="room_no" required>																						
			
							</select>
							<a type="button" href="room_info_main.php" target="_blank" class="btn btn-info">View rooms</a>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>					
					</div>
					<br>
					<!--<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="text" name="Name" placeholder="Name">
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter username:</font><br>
							<input type="text" id="mem_uname" name="mem_uname">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Enter password:</font><br>
							<input type="password" id="mem_pass" name="mem_pass">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">
						</div>
						<div class="clearfix"> </div>
					</div>-->					
					<!-- <textarea name="Message" placeholder="Message" required=""></textarea>-->
					<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="SUBMIT">
					</div>
					</center>
				</form>

				<?php
				
				?>
				
			</div>			
		</div>
<!--contact end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>