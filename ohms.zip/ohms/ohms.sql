-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 13, 2019 at 04:26 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ohms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `pass`) VALUES
('test', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `auto_gen_pay_id`
--

CREATE TABLE IF NOT EXISTS `auto_gen_pay_id` (
  `pay_id` int(100) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auto_gen_pay_id`
--

INSERT INTO `auto_gen_pay_id` (`pay_id`) VALUES
(0),
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);

-- --------------------------------------------------------

--
-- Table structure for table `complain_box`
--

CREATE TABLE IF NOT EXISTS `complain_box` (
  `com_id` int(100) NOT NULL,
  `mem_id` int(100) NOT NULL,
  `mem_name` varchar(100) NOT NULL,
  `atype` varchar(100) NOT NULL,
  `occup` varchar(100) NOT NULL,
  `room_no` varchar(100) NOT NULL,
  `complain` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complain_box`
--

INSERT INTO `complain_box` (`com_id`, `mem_id`, `mem_name`, `atype`, `occup`, `room_no`, `complain`, `date`, `reply`) VALUES
(0, 0, '', '', '', '', '', '', ''),
(1, 2, 'Arjun Mondal', 'Student', 'B.TECH', 'B2', 'complain1', '03/03/2017', 'reply1'),
(2, 1, 'Sabyasachi Moitra', 'Student', 'B.TECH', 'B2', 'complain2', '03/03/2017', '');

-- --------------------------------------------------------

--
-- Table structure for table `gate_pass`
--

CREATE TABLE IF NOT EXISTS `gate_pass` (
  `gate_pass_id` int(100) NOT NULL,
  `mem_id` int(100) NOT NULL,
  `mem_name` varchar(100) NOT NULL,
  `atype` varchar(100) NOT NULL,
  `occup` varchar(100) NOT NULL,
  `room_no` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `approve` varchar(100) NOT NULL,
  PRIMARY KEY (`gate_pass_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gate_pass`
--

INSERT INTO `gate_pass` (`gate_pass_id`, `mem_id`, `mem_name`, `atype`, `occup`, `room_no`, `reason`, `date`, `approve`) VALUES
(0, 0, '', '', '', '', '', '', ''),
(1, 2, 'Arjun Mondal', 'Student', 'B.TECH', 'B2', 'reason1', '03/03/2017', 'NO'),
(2, 1, 'Sabyasachi Moitra', 'Student', 'B.TECH', 'B2', 'reason2', '03/03/2017', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `member_dates`
--

CREATE TABLE IF NOT EXISTS `member_dates` (
  `mem_id` int(100) NOT NULL,
  `dor` varchar(100) NOT NULL,
  `doapp` varchar(100) NOT NULL,
  `doact` varchar(100) NOT NULL,
  `dodeact` varchar(100) NOT NULL,
  `dol` varchar(100) NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_dates`
--

INSERT INTO `member_dates` (`mem_id`, `dor`, `doapp`, `doact`, `dodeact`, `dol`) VALUES
(8, '24/12/2017', '24/12/2017', '24/12/2017', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `member_master`
--

CREATE TABLE IF NOT EXISTS `member_master` (
  `mem_id` int(100) NOT NULL,
  `mem_name` varchar(100) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `phno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `gphno` varchar(100) NOT NULL,
  `atype` varchar(100) NOT NULL,
  `occup` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `room_no` varchar(100) NOT NULL,
  `mem_uname` varchar(100) NOT NULL,
  `mem_pass` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `app_status` varchar(100) NOT NULL,
  `mem_status` varchar(100) NOT NULL,
  PRIMARY KEY (`mem_id`,`mem_uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_master`
--

INSERT INTO `member_master` (`mem_id`, `mem_name`, `addr`, `phno`, `email`, `dob`, `gname`, `gphno`, `atype`, `occup`, `gender`, `room_no`, `mem_uname`, `mem_pass`, `pic`, `app_status`, `mem_status`) VALUES
(0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(1, 'Sabyasachi Moitra', 'Shibrampur', '9432108330', 'sabyasachimoitra@rediffmail.com', '1990-06-22', 'K.P.Moitra', '9163903020', 'Student', 'B.TECH', 'Male', 'B1', 'smoitra', 'cdd36cbf68b4a0624b1fb43ae3d07f95', 'MyPic2.jpg', 'APPROVED', 'LEFT'),
(2, 'Arjun Mondal', 'Behala', '9831422974', 'mondal.arjun@gmail.com', '1990-07-23', 'P.K. Mondal', '7278737921', 'Student', 'B.TECH', 'Male', 'B2', 'amondal', 'amondal', 'blank-image.png', 'APPROVED', 'LEFT'),
(3, 'siddhan khata', '1 ishan mondal garden road kolkata 700038', '9051767274', 'sidd.khata@gmail.com', '2017-11-15', 's.khata', '9883098830', 'Student', 'DIPLOMA', 'Male', 'B1', 'sidd9051', '123456', 'blank-image.png', 'APPROVED', 'LEFT'),
(4, 'Gunjan Karmakar', 'Jadavpur', '123456', 'gk@gmail.com', '2017-11-01', 'a.karmakar', '1234567890', 'Student', 'B.TECH', 'Male', 'B2', 'gkarmakar', 'e10adc3949ba59abbe56e057f20f883e', 'blank-image.png', 'APPROVED', 'LEFT'),
(6, 'k.p.moitra', 'oxytown', '12345', 'kpm@gmail.com', '2017-11-09', 'm moitra', '123456', 'Staff', 'TEACHING STAFF', 'Male', 'gt1', 'kpmoitra', 'e10adc3949ba59abbe56e057f20f883e', 'blank-image.png', 'APPROVED', 'LEFT'),
(7, 'atanu', 'behala', '12345', 'a@xyz.com', '15/11/2017', 'tanu', '123456', 'Student', 'B.TECH', 'Male', 'b3', 'OHMS-7', '£šCªýžÕY×y*Ž³xŒ', 'blank-image.png', 'APPROVED', 'ACTIVE'),
(8, 'bijoya', 'kestopur', '12345', 'bm@abc.com', '24/12/2017', 'a mukherjee', '123456', 'Student', 'B.TECH', 'Female', 'G2', 'OHMS-8', '¨¨>“Ln[¦<*OéõÙ}À', 'blank-image.png', 'APPROVED', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `member_pay`
--

CREATE TABLE IF NOT EXISTS `member_pay` (
  `pay_id` int(100) NOT NULL,
  `mem_name` varchar(100) DEFAULT NULL,
  `mem_id` int(100) DEFAULT NULL,
  `atype` varchar(100) DEFAULT NULL,
  `occup` varchar(100) DEFAULT NULL,
  `room_no` varchar(100) DEFAULT NULL,
  `fee_type` varchar(100) DEFAULT NULL,
  `fee_amt` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_pay`
--

INSERT INTO `member_pay` (`pay_id`, `mem_name`, `mem_id`, `atype`, `occup`, `room_no`, `fee_type`, `fee_amt`, `date`) VALUES
(0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notice_board`
--

CREATE TABLE IF NOT EXISTS `notice_board` (
  `not_id` int(100) NOT NULL,
  `sender_type` varchar(100) NOT NULL,
  `send_mem_id` int(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `body` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `recv_mem_id` int(100) NOT NULL,
  PRIMARY KEY (`not_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_board`
--

INSERT INTO `notice_board` (`not_id`, `sender_type`, `send_mem_id`, `sub`, `body`, `date`, `time`, `recv_mem_id`) VALUES
(0, '', 0, '', '', '', '', 0),
(1, 'admin', 0, 's1', 'b1', '24/12/2017', '09:39pm', 0),
(2, 'admin', 0, 's2', 'b2', '24/12/2017', '09:40pm', 7);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `room_no` varchar(100) NOT NULL,
  `building` varchar(100) NOT NULL,
  `beds_taken` int(100) NOT NULL,
  `total_beds` varchar(100) NOT NULL,
  PRIMARY KEY (`room_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_no`, `building`, `beds_taken`, `total_beds`) VALUES
('B1', 'Boys Hostel', 0, '4'),
('B2', 'Boys Hostel', 0, '4'),
('B3', 'Boys Hostel', 0, '4'),
('G1', 'Girls Hostel', 0, '4'),
('G2', 'Girls Hostel', 1, '4'),
('G3', 'Girls Hostel', 0, '4'),
('GT1', 'Gents Hostel', 0, '4'),
('GT2', 'Gents Hostel', 0, '4'),
('GT3', 'Gents Hostel', 0, '4'),
('L1', 'Ladies Hostel', 0, '4'),
('L2', 'Ladies Hostel', 0, '4'),
('L3', 'Ladies Hostel', 0, '4');

-- --------------------------------------------------------

--
-- Table structure for table `staff_fee_struc`
--

CREATE TABLE IF NOT EXISTS `staff_fee_struc` (
  `occup` varchar(100) NOT NULL,
  `fee_per_month` varchar(100) NOT NULL,
  PRIMARY KEY (`occup`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_fee_struc`
--

INSERT INTO `staff_fee_struc` (`occup`, `fee_per_month`) VALUES
('NON-TEACHING STAFF', '1000'),
('TEACHING STAFF', '1500');

-- --------------------------------------------------------

--
-- Table structure for table `stud_fee_struc`
--

CREATE TABLE IF NOT EXISTS `stud_fee_struc` (
  `occup` varchar(100) NOT NULL,
  `fee_per_month` varchar(100) NOT NULL,
  PRIMARY KEY (`occup`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_fee_struc`
--

INSERT INTO `stud_fee_struc` (`occup`, `fee_per_month`) VALUES
('B.TECH', '500'),
('DIPLOMA', '300'),
('MBA', '700');
