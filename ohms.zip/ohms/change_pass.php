<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php
$email=$_GET['email'];
?>
<html>
<head>
<title>OHMS | Change Password</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!-- <span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a class="active" href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">				
				<p> </p>
			</div>
			<form action="change_pass_2.php" method="post">
				<div class="contact-grid">
					<div class="col-md-4 contact-us">
						<input type="hidden" id="email" name="email" value="<?php echo $email;?>">
					</div>
					<div class="col-md-4 contact-us">
						Enter new password:
						<input type="password" id="npass" name="npass">
					</div>
					<div class="col-md-4 contact-us">
						<!--<input type="text" name="Email" placeholder="Email">-->
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="contact-grid">
					<div class="col-md-4 contact-us">
						<!-- <input type="text" name="Name" placeholder="Name">-->
					</div>
					<div class="col-md-4 contact-us">
						Confirm password:
						<input type="password" id="cpass" name="cpass">
					</div>
					<div class="col-md-4 contact-us">
						<!--<input type="text" name="Email" placeholder="Email">-->
					</div>
					<div class="clearfix"> </div>
				</div>
				<center>
				<div class="send">
					<input type="submit" id="submit" name="submit" value="SUBMIT">
				</div>
				</center>				
			</form>			
			<!--<div class="about-bottom-main">
				<div class="about-bot">
			  		<div class="col-md-6 about-bot-left">
			  			<div class="col-md-4 advan-cup">
			  				<a href="#" rel="title" class="zoom-mask">
							    <span class="glyphicon glyphicon-education hovicon effect-4 sub-b" aria-hidden="true"> </span>
						       </a>
			  			</div>
			  			 <div class="col-md-8 advan-text">
				  				<h4>There are variations</h4>
				  				<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</p>
			  			 </div>	
			  		  <div class="clearfix"> </div>
			  		</div>
			  		<div class="col-md-6 about-bot-right">
			  			<div class="col-md-4 advan-cup">
			  				<a href="#" rel="title" class="zoom-mask"> 
							       <span class="glyphicon glyphicon-leaf hovicon effect-4 sub-b" aria-hidden="true"> </span>
						       </a>
			  			</div>
			  			 <div class="col-md-8 advan-text">
				  				<h4>There are variations</h4>
				  				<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</p>
			  			 </div>	
			  		  <div class="clearfix"> </div>
			  		</div>
			  		<div class="clearfix"> </div>
			  	</div>
			  	<div class="about-bot">
			  		<div class="col-md-6 about-bot-left">
			  			<div class="col-md-4 advan-cup">
			  				<a href="#" rel="title" class="zoom-mask">
			  					 <span class="glyphicon glyphicon-piggy-bank hovicon effect-4 sub-b" aria-hidden="true"> </span>							       
						       </a>
			  			</div>
			  			 <div class="col-md-8 advan-text">
				  				<h4>There are variations</h4>
				  				<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</p>
			  			 </div>	
			  		  <div class="clearfix"> </div>
			  		</div>
			  		<div class="col-md-6 about-bot-right">
			  			<div class="col-md-4 advan-cup">
			  				<a href="#" rel="title" class="zoom-mask">
							       <span class="glyphicon glyphicon-eye-open hovicon effect-4 sub-b" aria-hidden="true"> </span>
						       </a>
			  			</div>
			  			 <div class="col-md-8 advan-text">
				  				<h4>There are variations</h4>
				  				<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete</p>
			  			 </div>	
			  		  <div class="clearfix"> </div>
			  		</div>
			  		<div class="clearfix"> </div>
			  	</div>
			</div>-->
		</div>
	</div>
</div>
<!--about end here-->
<!--testimonial start here-->
<!--<div class="testimonial">
	<div class="container">
		<div class="testimonial-main">
			<h3>Testimonial</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		</div>
	</div>
</div>
<!--testimonial end here-->
<!--team start here-->
<!--<div class="team">
	<div class="container">
		<div class="team-main">
			<div class="team-top" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInDown;">
				<h3>Volunteers</h3>
				
			</div>
			<div class="team-bottom" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;">
			  <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t1.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Malorum</h3>		          
			          </div>			          
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			        
			    <!-- end normal -->
			   <!--</div>
			  <div class="col-md-3 team-grids">
			   <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t2.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Bonorum</h3>		           	            
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->		 
			  <!--</div>
			  <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t3.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Finibus</h3>			       
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->
			  <!--</div>
			   <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t4.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Rackham</h3>		           
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->			 
			  <!--</div>
			</div>
		</div>
	</div>
</div>
<!--team end here-->
<!--footer start here-->
<!--<div class="footer">
	<div class="container">
		<div class="footer-main">
			<div class="col-md-4 ftr-grid">
				<h3>Navigation</h3>
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="shortcodes.html">Short Codes</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</div>
			<div class="col-md-4 ftr-grid">
				<h3>Latest Tweet</h3>
				<div class="tweets">
					<div class="tweet-icon">
						<span class="tweet-img"> </span>
					</div>
					<div class="tweet-text">
						<p>Lorem ipsum</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur But I must explain to you how all this mistaken.</p>
			</div>
			<div class="col-md-4 ftr-grid">
				<h3>Keep In Touch</h3>
				<div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-map-marker">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-earphone">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>+12 894 8579</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-envelope">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p><a href="mailto:info@example.com">lorem@example.com</a></p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			</div>
			<div class="clearfix"> </div>		
		</div>
	</div>
</div>
<!--footer end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>