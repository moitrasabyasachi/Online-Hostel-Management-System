<?php
	echo '<option value="" selected>-- Select --</option>';
	
	$building=$_REQUEST['building'];
				
	include("connec.php");	//database parameters

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}	
	
	$sql = "SELECT * FROM room where building='$building' and total_beds-beds_taken<>0";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
		// output data of each row						
		while($row = mysqli_fetch_assoc($result)) {								
			$room_no=$row["room_no"];
			//echo $room_no;
			echo '<option value="'.$room_no.'">'.$room_no.'</option>';
		}
	} else {
		//echo "<center>No room to display</center>";
	}

	mysqli_close($conn);	
?>