<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Staff Portal | Payment Portal | Make Payment</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script type="text/javascript">
function jsFunction3(occup)
{
	switch(occup)
    {
        case "TEACHING STAFF" :
			document.getElementById("fee_amt").value="1000";			        
            
			break;
			
        case "NON-TEACHING STAFF" :
			document.getElementById("fee_amt").value="500";			           
            
			break;			
    }
}
</script>
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li></li>
					<li><a href="staff_pay_info.php"><i class="glyphicon glyphicon-file"> </i>Payment Information</a></li>
					<li><a class="active" href="staff_pay_2.php"><i class="glyphicon glyphicon-credit-card"> </i>Make Payment</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/<a href="staff_info.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-user"></span> Staff Portal</a>/ <span class="glyphicon glyphicon-credit-card"></span> Payment Portal</div>    
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>		
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Staff Fees Payment</h3>					
				</div>
				<form action="staff_pay_2.php" method="post">
				<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Member ID:</font><br>
							<select id="mem_id" name="mem_id">
								<option value="select" selected>-- Select --</option>
								
							<?php
							
							//staff member ids
							
							include("connec.php");	//database parameters

							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 

							$sql = "SELECT mem_id FROM member_master where mem_id<>0 and atype='Staff' and status='APPROVED'";
							$result = $conn->query($sql);
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo '<option value="'.$row['mem_id'].'">'.$row['mem_id'].'</option>';
								}	
								
							} else {
								//echo "";
							}
							$conn->close();
							?>
								
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
				</div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Submit">
					</div>
					</center>
				</form>
				
			<!-- staff search starts -->
			<?php
			if(isset($_POST['submit']) && $_POST['mem_id']!="select") {
				
				include("connec.php");	//database parameters

				$mem_id=$_POST["mem_id"];				

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}

				$sql = "SELECT * FROM member_master where mem_id='$mem_id'";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {    
					// output data of each row
					while($row = $result->fetch_assoc()) {
						$mem_id=$row["mem_id"];
						$mem_name=$row["mem_name"];
						$atype=$row["atype"];
						$occup=$row["occup"];								
						$room_no=$row["room_no"];						
					}	
				} else {
					//echo "Record not found";
				}
				
				
				$sql2 = "SELECT * FROM member_$mem_id";
				$result2 = $conn->query($sql2);

				if ($result2->num_rows > 0) {    
					// output data of each row
					while($row = $result2->fetch_assoc()) {
						$pay_mon=$row["fee_type_mon"];						
					}	
				} else {
					//echo "Record not found";
				}
				
				$sql3 = "SELECT * FROM room where room_no='$room_no'";
				$result3 = mysqli_query($conn, $sql3);
				
				if (mysqli_num_rows($result3) > 0) {
					// output data of each row						
					while($row = mysqli_fetch_assoc($result3)) {								
						$building=$row["building"];								
					}
				} else {
					//echo "";
				}

				$conn->close();
			}
			?>
			<!-- staff search ends -->
			
		<!-- auto number generation starts -->		
		<?php				
		include("connec.php");	//database parameters
				
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM auto_gen_pay_id";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$b = $row["pay_id"];
				$c=intval($b);
				$r=$c+1;

				//echo $d;
			}
		}
				
		$conn->close();
		?>
<!-- auto number generation ends -->
				
				<br>
				<br>
				<br>
				<form action="staff_pay_2.php" method="post">					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="hidden" id="pay_id" name="pay_id" value="<?php echo $r; ?>">
						</div>
						<div class="col-md-4 contact-us">
							Name:<br>
							<input type="text" id="mem_name" name="mem_name" value="<?php if(isset($_POST['submit'])){echo $mem_name;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<input type="hidden" id="mem_id" name="mem_id" value="<?php if(isset($_POST['submit'])){echo $mem_id;} ?>">
						</div>
						<div class="clearfix"> </div>
					</div>										
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="hidden" id="atype" name="atype" value="<?php if(isset($_POST['submit'])){echo $atype;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							Occupation:<br>
							<input type="text" id="occup" name="occup" value="<?php if(isset($_POST['submit'])){echo $occup;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Hostel.:<br>							
							<input type="text" id="room_no" name="room_no" value="<?php if(isset($_POST['submit'])){echo $building;} ?>">																					
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Room no.:<br>							
							<input type="text" id="room_no" name="room_no" value="<?php if(isset($_POST['submit'])){echo $room_no;} ?>">																					
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Payment Month:<br>							
							<select id="pay_mon" name="pay_mon" onchange="jsFunction3(document.getElementById('occup').value)">
								<option value="select" selected>-- Select --</option>								
								
								<?php
								
								if(isset($_POST['submit']))
								{
										if($pay_mon=="jan")
										{
											echo '<option value="feb">February</option>';
											echo '<option value="mar">March</option>';
											echo '<option value="apr">April</option>';
											echo '<option value="may">May</option>';
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="feb")
										{											
											echo '<option value="mar">March</option>';
											echo '<option value="apr">April</option>';
											echo '<option value="may">May</option>';
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="mar")
										{											
											echo '<option value="apr">April</option>';
											echo '<option value="may">May</option>';
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="apr")
										{											
											echo '<option value="may">May</option>';
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="may")
										{											
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="jun")
										{
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="jul")
										{											
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="aug")
										{								
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="sept")
										{										
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="oct")
										{											
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="nov")
										{											
											echo '<option value="dec">December</option>';
										}
										else if($pay_mon=="dec")
										{											
										}
										else
										{
											echo '<option value="jan">January</option>';
											echo '<option value="feb">February</option>';
											echo '<option value="mar">March</option>';
											echo '<option value="apr">April</option>';
											echo '<option value="may">May</option>';
											echo '<option value="jun">June</option>';
											echo '<option value="jul">July</option>';
											echo '<option value="aug">August</option>';
											echo '<option value="sept">September</option>';
											echo '<option value="oct">October</option>';
											echo '<option value="nov">November</option>';
											echo '<option value="dec">December</option>';
										}									
								}	
								?>
								
							</select>														
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Amount(Rs.):<br>							
							<input type="text" id="fee_amt" name="fee_amt">																					
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Date:<br>							
							<input type="text" id="date" name="date" value="<?php echo date("d/m/Y"); ?>">																					
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<center>
					<div class="send">
						<input type="submit" id="submit2" name="submit2" value="Make Payment">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->

<!--make payment start here-->
<?php
		
	if(isset($_POST['submit2'])){
	
	include("connec.php");	//database parameters

	$pay_id=$_POST["pay_id"];	
	$mem_name=$_POST["mem_name"];
	$mem_id=$_POST["mem_id"];
	$atype=$_POST["atype"];
	$occup=$_POST["occup"];
	$room_no=$_POST["room_no"];
	$pay_mon=$_POST["pay_mon"];	
	$fee_amt=$_POST["fee_amt"];
	$date=$_POST["date"];
	
	$_SESSION["mem_id"]=$mem_id;

	echo "pay_mon=".$pay_mon;
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "INSERT INTO member_$mem_id VALUES('$pay_id','$mem_name','$mem_id','$atype','$occup','$room_no','$pay_mon','$fee_amt','$date')";
	$sql2 = "INSERT INTO auto_gen_pay_id VALUES('$pay_id')";

	if ($conn->query($sql) === TRUE) {
			$conn->query($sql2);
			header('Location: pay_reciept.php');
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
	}
?>
<!--make payment end here-->

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>