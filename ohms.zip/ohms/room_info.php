<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Room Management | Room Information</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php include("logo.html");	?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li><a class="active" href="room_info.php"><i class="glyphicon glyphicon-home"> </i>Room Information</a></li>
					<li><a href="add_room.php"><i class="glyphicon glyphicon-home"> </i>Add<br>Room</a></li>					
					<li><a href="update_room.php"><i class="glyphicon glyphicon-home"> </i>Update Room</a></li>
					<li><a href="del_room.php"><i class="glyphicon glyphicon-home"> </i>Delete Room</a></li>
					<li><a href="room_mem.php"><i class="glyphicon glyphicon-user"> </i>Room Members</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Room Management</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>
</div>
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Room Information</h2>
				<p> </p>
			</div>
					<div class="table-users" style="width:100%;">
					<table align="center">						
						<tr><td colspan="4"><center><b>BOYS HOSTEL</b></center></td></tr>
						<tr>
							<td align="center"><b>Room No.</b></td>							
							<td align="center"><b>Total Beds</b></td>
							<td><center><b>Beds Taken</b></center></td>
							<td><center><b>Beds Available</b></center></td>
						</tr>
						
				<?php
	
				//room information, boys hostel
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM room where building='Boys Hostel'";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$room_no=$row["room_no"];
								//$building=$row["building"];
								$total_beds=$row["total_beds"];
								$beds_taken=$row["beds_taken"];
								$beds_avail=$total_beds-$beds_taken;
								
								echo "<tr><td>".$room_no."</td><td>".$total_beds."</td><td><center>".$beds_taken."</center></td><td><center>".$beds_avail."</center></td></tr>";
						}
				} else {
					//echo "<center>No room to display</center>";
				}

				mysqli_close($conn);
	
				?>
			
			</table>
			</div>
					
					<div class="table-users" style="width:100%;">
					<table align="center">
					<tr><td colspan="4"><center><b>GIRLS HOSTEL</b></center></td></tr>
						<tr>
							<td align="center"><b>Room No.</b></td>							
							<td align="center"><b>Total Beds</b></td>
							<td><center><b>Beds Taken</b></center></td>
							<td><center><b>Beds Available</b></center></td>							
						</tr>
						
				<?php
				
				//room information, girls hostel
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM room where building='Girls Hostel'";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$room_no=$row["room_no"];
								//$building=$row["building"];
								$total_beds=$row["total_beds"];
								$beds_taken=$row["beds_taken"];
								$beds_avail=$total_beds-$beds_taken;
								
								echo "<tr><td>".$room_no."</td><td>".$total_beds."</td><td><center>".$beds_taken."</center></td><td><center>".$beds_avail."</center></td></tr>";
						}
				} else {
					//echo "<center>No room to display</center>";
				}

				mysqli_close($conn);
	
			?>
			</table>
			</div>
			
					<div class="table-users" style="width:100%;">
					<table align="center">
					<tr><td colspan="4"><center><b>GENTS HOSTEL</b></center></td></tr>
						<tr>
							<td align="center"><b>Room No.</b></td>							
							<td align="center"><b>Total Beds</b></td>
							<td><center><b>Beds Taken</b></center></td>
							<td><center><b>Beds Available</b></center></td>							
						</tr>
						
				<?php
	
				//room information, gents hostel
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM room where building='Gents Hostel'";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$room_no=$row["room_no"];
								//$building=$row["building"];
								$total_beds=$row["total_beds"];
								$beds_taken=$row["beds_taken"];
								$beds_avail=$total_beds-$beds_taken;
								
								echo "<tr><td>".$room_no."</td><td>".$total_beds."</td><td><center>".$beds_taken."</center></td><td><center>".$beds_avail."</center></td></tr>";
						}
				} else {
					//echo "<center>No room to display</center>";
				}

				mysqli_close($conn);
	
			?>
			</table>
			</div>
			
					<div class="table-users" style="width:100%;">
					<table align="center">
					<tr><td colspan="4"><center><b>LADIES HOSTEL</b></center></td></tr>
						<tr>
							<td align="center"><b>Room No.</b></td>							
							<td align="center"><b>Total Beds</b></td>
							<td><center><b>Beds Taken</b></center></td>
							<td><center><b>Beds Available</b></center></td>							
						</tr>
						
				<?php
				
				//room information, ladies hostel
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM room where building='Ladies Hostel'";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$room_no=$row["room_no"];
								//$building=$row["building"];
								$total_beds=$row["total_beds"];
								$beds_taken=$row["beds_taken"];
								$beds_avail=$total_beds-$beds_taken;
								
								echo "<tr><td>".$room_no."</td><td>".$total_beds."</td><td><center>".$beds_taken."</center></td><td><center>".$beds_avail."</center></td></tr>";
						}
				} else {
					//echo "<center>No room to display</center>";
				}

				mysqli_close($conn);
	
				?>
					</table>
					</div>
					
		</div>
	</div>
</div>
<!--about end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>