<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_member.php') ;
else
{
$mem_id=$_SESSION['mid'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id='$mem_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mem_name=$row['mem_name'];
		$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Member | Complaints</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
<style>
.image 
{
    border: 3px solid;
    border-color: #daeff1;
    height: 100px;
    margin: 0.5rem 0;
	width: 100px;
}
</style>
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php echo "<img class='image' src='uploads/".$pic."'/><span><font size='6' color='white'>&nbsp;".$mem_name."</font></span>";?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li><a href="mem_prof.php"><i class="glyphicon glyphicon-user"> </i>Profile</a></li>
					<li><a class="active" href="complaints.php"><i class="glyphicon glyphicon-envelope"> </i>Complaints</a></li>					
					<li><a href="gate_pass.php"><i class="glyphicon glyphicon-envelope"> </i>Gate Pass</a></li>
					<li><a href="notice.php"><i class="glyphicon glyphicon-envelope"> </i>Notices</a></li>
					<li><a href="logout.php"><i class="glyphicon glyphicon-log-out"> </i>Logout</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-12"><a href="mem_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a></div>    
  </div>
</div>
			<!--member details-->
			<?php
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM member_master where mem_id=$mem_id";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$mem_name=$row["mem_name"];
						$atype=$row["atype"];	
						$occup=$row["occup"];							
						$room_no=$row["room_no"];						
					}
				}else {
					//echo "";
				}

				mysqli_close($conn);
	
				?>

<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Complaints</h2>
				<p> </p>
			</div>
			<div class="row">
				<div class="col-md-12">
				<p>
					<div class="table-users" style="width:100%;">
					<table align="center" width="100%">						
						<tr>							
							<td align="center" width="25%"><b>Date</b></td>
							<td align="center" width="50%"><b>Complain</b></td>
							<td width="25%"><center><b>Reply</b></center></td>
						</tr>
				
				<!--complain box-->
				<?php
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM complain_box where mem_id=$mem_id";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$complain=$row["complain"];
						$date=$row["date"];						
						$reply=$row["reply"];						
						
						echo "<tr><td>".$date."</td><td>".$complain."</td><td><center>".$reply."</center></td></tr>";
					}
				}else {
					//echo "<center>Nothing to display</center>";
				}

				mysqli_close($conn);
	
				?>						
					</table>
					</div>
				</p>
				</div>				
			</div>			
		</div>
		<br>
		<br>
		<br>
		
		<!-- auto number generation starts -->		
		<?php				
		include("connec.php");	//database parameters
				
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM complain_box";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$b = $row["com_id"];
				$c=intval($b);
				$r=$c+1;

				//echo $d;
			}
		}
				
		$conn->close();
		?>
		<!-- auto number generation ends -->
		
		<form action="complaints.php" method="post">				
				<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="hidden" id="com_id" name="com_id" value="<?php echo $r; ?>">
						</div>
						<div class="col-md-4 contact-us">
							Complain:<br>							
							<textarea class="mystyle2" name="complain" required=""></textarea>
						</div>
						<div class="col-md-4 contact-us">
							<input type="hidden" id="date" name="date" value="<?php echo date("d/m/Y"); ?>">
						</div>
						<div class="clearfix"> </div>
				</div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Submit">
					</div>
				</center>
		</form>
	</div>
</div>
<!--about end here-->

<!--generate complain start here-->
<?php
		
	if(isset($_POST['submit'])){
	
	include("connec.php");	//database parameters

	$com_id=$_POST["com_id"];
	$complain=$_POST["complain"];
	$date=$_POST["date"];	

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "INSERT INTO complain_box VALUES ('$com_id', '$mid', '$mem_name','$atype','$occup','$room_no','$complain','$date','')";	

	if ($conn->query($sql) === TRUE) {
			echo "<p align='center'>complain made successfully.....</p>";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();	
	}
?>
<!--generate complain end here-->

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>