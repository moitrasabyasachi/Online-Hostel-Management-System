<?php
session_start();

$user=$_SESSION["un"];
if($user=="")
	header('Location: login_manager.php') ;
else	
	$fname=$_SESSION["fname"];
?>
<html>
<head>
<title>Payment Reciept Copy</title>
<script>
function myFunction() {
    window.print();
}
</script>
</head>
<body>
<?php
$pay_id=$_POST['pay_id'];

include("connec.php");	//database parameters

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
	
$sql = "SELECT * FROM member_pay WHERE pay_id=$pay_id";
$result = mysqli_query($conn, $sql);				

if (mysqli_num_rows($result) > 0) {
	// output data of each row						
	while($row = mysqli_fetch_assoc($result)) {								
		//$pay_id=$row["pay_id"];
		$mem_id=$row["mem_id"];
		$mem_name=$row["mem_name"];
		$atype=$row["atype"];
		$occup=$row["occup"];								
		$room_no=$row["room_no"];								
		$fee_type=$row["fee_type"];
		$fee_amt=$row["fee_amt"];
		$date=$row["date"];
								
		/*if($atype=="Student")
		{
			if($fee_type_mon=="jan")
				$fee_type_mon="January";
			if($fee_type_mon=="feb")
				$fee_type_mon="February";
			if($fee_type_mon=="mar")
				$fee_type_mon="March";
			if($fee_type_mon=="apr")
				$fee_type_mon="April";
			if($fee_type_mon=="may")
				$fee_type_mon="May";
			if($fee_type_mon=="jun")
				$fee_type_mon="June";
			if($fee_type_mon=="jul")
				$fee_type_mon="July";
			if($fee_type_mon=="aug")
				$fee_type_mon="August";
			if($fee_type_mon=="sept")
				$fee_type_mon="September";
			if($fee_type_mon=="oct")
				$fee_type_mon="October";
			if($fee_type_mon=="nov")
				$fee_type_mon="November";
			if($fee_type_mon=="dec")
				$fee_type_mon="December";
		}
		if($atype=="Staff")
		{
			if($fee_type_mon=="jan")
				$fee_type_mon="January";
			if($fee_type_mon=="feb")
				$fee_type_mon="February";
			if($fee_type_mon=="mar")
				$fee_type_mon="March";
			if($fee_type_mon=="apr")
				$fee_type_mon="April";
			if($fee_type_mon=="may")
				$fee_type_mon="May";
			if($fee_type_mon=="jun")
				$fee_type_mon="June";
			if($fee_type_mon=="jul")
				$fee_type_mon="July";
			if($fee_type_mon=="aug")
				$fee_type_mon="August";
			if($fee_type_mon=="sept")
				$fee_type_mon="September";
			if($fee_type_mon=="oct")
				$fee_type_mon="October";
			if($fee_type_mon=="nov")
				$fee_type_mon="November";
			if($fee_type_mon=="dec")
				$fee_type_mon="December";
		}*/
								
		$sql2 = "SELECT * FROM room where room_no='$room_no'";
		$result2 = mysqli_query($conn, $sql2);
				
		if (mysqli_num_rows($result2) > 0) {
			// output data of each row						
			while($row = mysqli_fetch_assoc($result2)) {								
				$building=$row["building"];								
			}
		} else {
			//echo "";
		}
	}
} else {
	//echo "<center>No member to display</center>";
}

mysqli_close($conn);
?>
<p></p>
<table border="1" align="center" width="50%">
<tr><td colspan="2"><?php include("logo.html");	?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font></td></tr>
<tr><td colspan="2" align="center">Reciept for Payment of Hostel Fees. This Reciept is generated from OHMS Portal</td></tr>
<tr><td width="25%">Reciept No.</td><td width="25%">OHMS/PR/<?php echo $pay_id;?></td></tr>
<tr><td width="25%">Member ID</td><td width="25%"><?php echo $mem_id;?></td></tr>
<tr><td width="25%">Name</td><td width="25%"><?php echo $mem_name;?></td></tr>
<tr><td width="25%">Member Type</td><td width="25%"><?php echo $atype;?></td></tr>
<tr><td width="25%">Occupation</td><td width="25%"><?php echo $occup;?></td></tr>
<tr><td width="25%">Hostel</td><td width="25%"><?php echo $building;?></td></tr>
<tr><td width="25%">Room No.</td><td width="25%"><?php echo $room_no;?></td></tr>
<tr><td width="25%">Fee Type</td><td width="25%"><?php echo $fee_type_mon;?></td></tr>
<tr><td width="25%">Fee Amount</td><td width="25%">Rs.<?php echo $fee_amt;?></td></tr>
<tr><td width="25%">Date</td><td width="25%"><?php echo $date;?></td></tr>
<tr><td width="25%">Authorized Signature</td><td width="25%"></td></tr>
</table>
<p></p>
<center><button onclick="myFunction()">Print</button></center>
<p></p>
<center><a href="<?php echo $fname;?>">Back</a></center>
</body>
</html>