<?php			
session_start();

$mem_id=$_SESSION['mid'];

if(isset($_POST['upp']))
{			
	if (isset ($_FILES['fileToUpload']))
	{
		$target_dir = "images/";
		$file_name = basename($_FILES["fileToUpload"]["name"]);
		$target_file = $target_dir . $file_name;
		$uploadOk = 0;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg")
		{
			echo '<script language="javascript">';
			echo 'alert("Sorry, only JPG, JPEG & PNG files are allowed.")';
			echo '</script>';    			

    		$uploadOk = 1;
		}

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 1) 
		{
			echo '<script language="javascript">';
			echo 'alert("Sorry, your file was not uploaded.")';
			echo '</script>';
			
			header("refresh:1;url=edit_prof.php");
		}
		// if everything is ok, try to upload file 
		else 
		{
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))
			{
				include("connec.php");	//database parameters
	
				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
	
				// Check connection
				if (!$conn) 
				{
					die("Connection failed: " . mysqli_connect_error());
				}

				$sql = "UPDATE member_master SET pic='$file_name' WHERE mem_id='$mem_id'";

				if ($conn->query($sql) === TRUE) 
				{
					echo '<script language="javascript">';
					echo 'alert("Profile picture uploaded successfully")';
					echo '</script>';

					header("refresh:1;url=edit_prof.php");
				}
				else
				{
					//echo "Error: " . $sql . "<br>" . $conn->error;
				}

				$conn->close();   
			}
			else
			{
				echo '<script language="javascript">';
				echo 'alert("Sorry, there was an error uploading your file.")';
				echo '</script>';
				
				header("refresh:1;url=edit_prof.php");
			}
		}
	
			
?>