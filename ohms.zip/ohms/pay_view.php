<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
else{
$fname=$_SESSION["fname"];	

$mid=$_POST['mem_id'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id=$mid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //$pay_id=$row['pay_id'];
		$mname=$row['mem_name'];
		//$fee_type=$row['fee_type'];
		//$fee_amt=$row['fee_amt'];
		//$date=$row['date'];		
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>


<html>
<head>
<title>OHMS | Admin | Student Portal | Payment Portal | Payment Information | Payments</title>
</head>
<body>
<table border="0" align="center" width="100%">
<tr><td align="center"><hr><?php include("logo.html");?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font><hr></td></tr>
<tr><td><b>Member ID:</b> <?php echo $mid;?></td></tr>
<tr><td><b>Member Name:</b> <?php echo $mname;?></td></tr>
<tr><th align="center"><hr>PAYMENTS<hr></th></tr>
</table>

				<?php
				
				//total payment
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$sql2="SELECT SUM(fee_amt) AS total_fee FROM member_pay WHERE pay_id<>0 AND mem_id=$mid";
				$result2 = mysqli_query($conn, $sql2);

				$total_fee=0;
				if (mysqli_num_rows($result2) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result2)) {								
						$total_fee=$row['total_fee'];						
					}					
				}else {
					//echo "<center>Nothing to display</center>";
				}
				
				echo "<h3 align='center'>TOTAL FEES PAID TILL DATE : Rs.".$total_fee."</h3>";
				
				mysqli_close($conn);
	
				?>
				
<table border="1" align="center" width="100%">									
<tr>																
<td align="center" width="20%"><b>Payment ID</b></td>
<td width="20%"><center><b>Fee Type</b></center></td>
<td align="center" width="20%"><b>Fee Amount</b></td>
<td align="center" width="20%"><b>Date</b></td>
<td width="20%"></td>
</tr>

				<?php
				
				//payments
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM member_pay WHERE pay_id<>0 AND mem_id=$mid";				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$pay_id=$row['pay_id'];		
						$fee_type=$row['fee_type'];
						$fee_amt=$row['fee_amt'];
						$date=$row['date'];		
						
						echo "<tr><td><center>".$pay_id."</center></td><td><center>".$fee_type."</center></td><td><center>".$fee_amt."</center></td><td><center>".$date."</center></td><td><center><form action='pay_reciept_copy.php' method='post'><input type='hidden' id='pay_id' name='pay_id' value=".$pay_id."><input type='submit' id='del' name='del' value='Print Reciept'></form></center></td></tr>";
					}					
				}else {
					//echo "<center>Nothing to display</center>";
				}				
				
				mysqli_close($conn);
	
				?>

</table>

<p></p>
<center><a href="<?php echo $fname;?>">Back</a></center>
<p></p>
<hr>

<?php
	echo "<center>";
	include("footer.html");
	echo "</center>";
?>
</body>
</html>