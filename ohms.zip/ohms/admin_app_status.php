<?php
	// Start the session
	session_start();
	
	$user=$_SESSION["un"];

	if($user=="")
		header('Location: login_manager.php') ;
?>

<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$mem_id=$_POST['mem_id'];
		$app_status=$_POST['submit'];

		include("connec.php");	//database parameters
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		
		if($app_status=="Reject")
		{
			$tsql = "SELECT * FROM member_master where mem_id=$mem_id";
			$tresult = mysqli_query($conn, $tsql);
				
			if (mysqli_num_rows($tresult) > 0) {
				// output data of each row						
				while($row = mysqli_fetch_assoc($tresult)) {								
					$room_no=$row["room_no"];								
				}
			} else {
				//echo "";
			}
			
			$tsql2 = "SELECT * FROM room where room_no='$room_no'";
			$tresult2 = mysqli_query($conn, $tsql2);

			if (mysqli_num_rows($tresult2) > 0) {
				// output data of each row						
				while($row = mysqli_fetch_assoc($tresult2)) {									
					$beds_taken=intval($row["beds_taken"]);								
				}
			} else {
				//echo "";
			}
			
			$sql = "DELETE FROM member_master WHERE mem_id=$mem_id";
			$sql2 = "UPDATE room SET beds_taken=$beds_taken-1 WHERE room_no='$room_no'";
			//$sql3 = "DROP TABLE member_$mem_id";

			if ($conn->query($sql) === TRUE) {
					$conn->query($sql2);
					//$conn->query($sql3);
					
					echo "<h1 align='center'>Application Rejected</h1>";
			} else {
				//echo "<p align='center'>Error deleting record: " . $conn->error . "</p>";
			}
			
			header("refresh:1;url=admin_home.php");
		}
		else if($app_status=="Approve")
		{
			$doapp=date('d/m/Y');
			$sql = "UPDATE member_master SET app_status='APPROVED', mem_status='INACTIVE' WHERE mem_id=$mem_id";
			$sql2 = "UPDATE member_dates SET doapp='$doapp' WHERE mem_id=$mem_id";

			if ($conn->query($sql) === TRUE) {
				echo "<h1 align='center'>Application Approved</h1>";
				$conn->query($sql2);
			} else {
				//echo "Error updating record: " . $conn->error;
			}			
			//header('Location: admin_home.php');
			header("refresh:1;url=admin_home.php");
		}
		
		$conn->close();
	?>
</body>
</html>