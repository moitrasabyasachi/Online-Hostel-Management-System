<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Application Status</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a class="active" href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a href="about.html"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Application Status</h2>
				<p> </p>
			</div>
			<form action="app_status.php" method="post">
			<div class="contact-grid">
				<div class="col-md-4 contact-us">
					<!-- <input type="text" name="Name" placeholder="Name">-->							
				</div>
				<div class="col-md-4 contact-us">
					Application ID:<br>
					<input type="text" id="mem_uname" name="mem_uname" style="text-transform:uppercase">
				</div>
				<div class="col-md-4 contact-us">
					<!--<input type="text" name="Email" placeholder="Email">-->
				</div>
				<div class="clearfix"> </div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Check">
					</div>
				</center>
			</div>
			</form>
		</div>
	</div>
				<br><br><br>
				<?php
				
				//application status check
				
				if(isset($_POST['submit'])) {
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$mem_uname=$_POST["mem_uname"];
	
				$sql = "SELECT * FROM member_master where mem_uname='$mem_uname'";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$app_status=$row["app_status"];
								$mem_id=$row["mem_id"];
								$mem_status=$row["mem_status"];
						}
				} else {
					//echo "<center>No room to display</center>";
				}

				if($app_status=="PENDING")
				{
					echo "<center><h1><font face='Comic Sans MS' color='red'>Your application is pending</font></h1></center>";										
				}
				else if($app_status=="HOLD")
				{
					echo "<center><h1><font face='Comic Sans MS' color='red'>Your application is on hold</font></h1></center>";										
				}
				else if($app_status=="APPROVED")
				{
					echo "<center><h1><font face='Comic Sans MS' color='green'>Your application has been approved</font></h1></center>";
					if($mem_status=="INACTIVE")
						echo "<br><center><form action='app_form_print.php' method='post'><input type='hidden' name='mem_id' value=".$mem_id."><input type='submit' id='submit2' class='btn btn-link' name='submit2' value='Click to print the form'></form></center>";
				}
				else if($app_status=="REJECTED")
				{
					echo "<center><h1><font face='Comic Sans MS' color='red'>Your application has been rejected</font></h1></center>";										
				}
				mysqli_close($conn);
				}
				?>
</div>
<!--about end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>