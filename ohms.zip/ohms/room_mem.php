<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Room Management | Room Members</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php include("logo.html");	?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li><a href="room_info.php"><i class="glyphicon glyphicon-home"> </i>Room Information</a></li>
					<li><a href="add_room.php"><i class="glyphicon glyphicon-home"> </i>Add<br>Room</a></li>					
					<li><a href="update_room.php"><i class="glyphicon glyphicon-home"> </i>Update Room</a></li>
					<li><a href="del_room.php"><i class="glyphicon glyphicon-home"> </i>Delete Room</a></li>
					<li><a class="active" href="room_mem.php"><i class="glyphicon glyphicon-user"> </i>Room Members</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="row">
    <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Room Management</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>    
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Room Members</h3>					
				</div>
				<form action="#" method="post">
				<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Room No.:<br>
							<select id="room_no" name="room_no">
								<option value="select" selected>-- Select --</option>
								
							<!--room nos-->
							
							<?php														
							include("connec.php");	//database parameters

							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 

							$sql = "SELECT room_no FROM room";
							$result = $conn->query($sql);
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo '<option value="'.$row['room_no'].'">'.$row['room_no'].'</option>';
								}	
								
							} else {
								//echo "";
							}
							$conn->close();
							?>
								
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
				</div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Submit">
					</div>
				</center>
				</form>								
			</div>			
		</div>
<!--contact end here-->
<div class="about">	
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<div class="table-users" style="width:100%;">
				<table align="center">						
					<tr>
						<td></td>
						<td align="center"><b>Member ID</b></td>
						<td align="center"><b>Name</b></td>
						<td align="center"><b>Phone No.</b></td>
						<td align="center"><b>Occupation</b></td>							
						<td align="center"><b>Gender</b></td>
						<td align="center"><b>Room No.</b></td>
						<td><center><b>Building</b></center></td>
					</tr>
					
			<?php
			
			//room members
			
			if(isset($_POST['submit']) && $_POST['room_no']!="select") {
				
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$room_no=$_POST['room_no'];
	
				$sql = "SELECT * FROM member_master where room_no='$room_no' and status='APPROVED'";
				$result = mysqli_query($conn, $sql);
				
				$sql2 = "SELECT * FROM room where room_no='$room_no'";
				$result2 = mysqli_query($conn, $sql2);
				
				if (mysqli_num_rows($result2) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result2)) {								
								$building=$row["building"];								
						}
				} else {
					//echo "";
				}

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
								$mem_id=$row["mem_id"];
								$mem_name=$row["mem_name"];
								$phno=$row["phno"];
								$occup=$row["occup"];
								$gender=$row["gender"];
								$pic=$row["pic"];
								
								echo "<tr><td><img src='uploads/".$pic."'/></td><td>".$mem_id."</td><td>".$mem_name."</td><td>".$phno."</td><td>".$occup."</td><td>".$gender."</td><td>".$room_no."</td><td><center>".$building."</center></td></tr>";
						}
				} else {
					//echo "<center>No member to display</center>";
				}

				mysqli_close($conn);
			}
			?>						
				</table>
				</div>
			</div>									
		</div>
	</div>
</div>
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>