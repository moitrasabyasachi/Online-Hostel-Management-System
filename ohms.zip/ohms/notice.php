<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$mid=$_SESSION['mid'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id='$mid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mem_name=$row['mem_name'];
		$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Member | Notice | Notice Board</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
<style>
.image 
{
    border: 3px solid;
    border-color: #daeff1;
    height: 100px;
    margin: 0.5rem 0;
	width: 100px;
}
</style>
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php echo "<img class='image' src='uploads/".$pic."'/><span><font size='6' color='white'>&nbsp;".$mem_name."</font></span>";?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li></li>					
					<li><a class="active" href="notice.php"><i class="glyphicon glyphicon-envelope"> </i>Notice Board</a></li>
					<li><a href="admin_msg.php"><i class="glyphicon glyphicon-envelope"> </i>Admin's Message</a></li>
					<li><a href="logout.php"><i class="glyphicon glyphicon-log-out"> </i>Logout<br>&nbsp;</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-12"><a href="mem_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-envelope"></span> Notices</div>    
  </div>
</div>
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Notice Board</h2>
				<p> </p>
			</div>				
								<div class="table-users" style="width:100%;">
								<table align="center" width="100%">									
									<tr>
										<td align="center" width="25%"><b>Date</b></td>
										<td align="center" width="50%"><b>Subject</b></td>
										<td width="25%"><center><b>Body</b></center></td>																	
									</tr>
				<?php
				
				//notices
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM notice_board WHERE not_id<>'0'";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$date=$row["date"];
						$sub=$row["sub"];
						$body=$row["body"];						
						
						echo "<tr><td>".$date."</td><td>".$sub."</td><td><center>".$body."</center></td></tr>";
					}
				}else {
					//echo "<center>Nothing to display</center>";
				}

				mysqli_close($conn);
	
				?>						
								</table>
								</div>								
		</div>
	</div>
</div>
<!--about end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>