<html>
<head>
<title>Application Form</title>
<script>
function myFunction() {
    window.print();
}
</script>
</head>
<body>
<?php
$mem_id=$_POST["mem_id"];

include("connec.php");	//database parameters

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
	
$sql = "SELECT * FROM member_master";
$result = mysqli_query($conn, $sql);				

if (mysqli_num_rows($result) > 0) {
	// output data of each row						
	while($row = mysqli_fetch_assoc($result)) {		
		$mem_id=$row["mem_id"];
		$mem_name=$row["mem_name"];
		$addr=$row["addr"];
		$phno=$row["phno"];
		$email=$row["email"];	
		$dob=$row["dob"];
		$gname=$row["gname"];	
		$gphno=$row["gphno"];
		$atype=$row["atype"];	
		$occup=$row["occup"];
		$gender=$row["gender"];
		$room_no=$row["room_no"];
		$app_status=$row["app_status"];
		$mem_status=$row["mem_status"];
								
		$sql2 = "SELECT * FROM room where room_no='$room_no'";
		$result2 = mysqli_query($conn, $sql2);
				
		if (mysqli_num_rows($result2) > 0) {
			// output data of each row						
			while($row = mysqli_fetch_assoc($result2)) {								
				$building=$row["building"];								
			}
		} else {
			//echo "";
		}
		
		$sql3 = "SELECT * FROM member_dates where mem_id=$mem_id";
		$result3 = mysqli_query($conn, $sql3);
				
		$dor='N/A';
		$doapp='N/A';
		
		if (mysqli_num_rows($result3) > 0) {
			// output data of each row						
			while($row = mysqli_fetch_assoc($result3)) {								
				$dor=$row["dor"];
				$doapp=$row["doapp"];
			}
		} else {
			//echo "";
		}
	}
} else {
	//echo "<center>No member to display</center>";
}

mysqli_close($conn);
?>
<h1 align="center">Member's Copy</h1>
<table border="1" align="center" width="50%">
<tr><td colspan="2"><?php include("logo.html");	?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font></td></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><th colspan="2" align="center">APPLICATION FORM</th></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><td width="25%"><b>Date of Registration</b></td><td width="25%"><?php echo $dor;?></td></tr>
<tr><td width="25%"><b>Member ID</b></td><td width="25%"><?php echo $mem_id;?></td></tr>
<tr><td width="25%"><b>Name</b></td><td width="25%"><?php echo $mem_name;?></td></tr>
<tr><td width="25%"><b>Address</b></td><td width="25%"><?php echo $addr;?></td></tr>
<tr><td width="25%"><b>Phone No.</b></td><td width="25%"><?php echo $phno;?></td></tr>
<tr><td width="25%"><b>Email ID</b></td><td width="25%"><?php echo $email;?></td></tr>
<tr><td width="25%"><b>Date of Birth</b></td><td width="25%"><?php echo $dob;?></td></tr>
<tr><td width="25%"><b>Guardian's Name</b></td><td width="25%"><?php echo $gname;?></td></tr>
<tr><td width="25%"><b>Guardian's Phone No.</b></td><td width="25%"><?php echo $gphno;?></td></tr>
<tr><td width="25%"><b>Member Type</b></td><td width="25%"><?php echo $atype;?></td></tr>
<tr><td width="25%"><b>Occupation</b></td><td width="25%"><?php echo $occup;?></td></tr>
<tr><td width="25%"><b>Hostel</b></td><td width="25%"><?php echo $building;?></td></tr>
<tr><td width="25%"><b>Room No.</b></td><td width="25%" style="text-transform:uppercase"><?php echo $room_no;?></td></tr>
<tr><td width="25%"><b>Application Status</b></td><td width="25%"><?php echo $app_status;?></td></tr>
<tr><td width="25%"><b>Date of Approval</b></td><td width="25%"><?php echo $doapp;?></td></tr>
<tr><td width="25%"><b>Account Status</b></td><td width="25%"><?php echo $mem_status;?></td></tr>
<tr><td width="25%"><b>Authorized Signature</b></td><td width="25%"></td></tr>
</table>
<p align="center">
*Bring the application form at the time of 1st payment. Payment must be done within 5 working days from the date of approval.
<p>
<p></p>
<hr>
<h1 align="center">Admin's Copy</h1>
<table border="1" align="center" width="50%">
<tr><td colspan="2"><?php include("logo.html");	?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font></td></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><th colspan="2" align="center">APPLICATION FORM</th></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><td width="25%"><b>Date of Registration</b></td><td width="25%"><?php echo $dor;?></td></tr>
<tr><td width="25%"><b>Member ID</b></td><td width="25%"><?php echo $mem_id;?></td></tr>
<tr><td width="25%"><b>Name</b></td><td width="25%"><?php echo $mem_name;?></td></tr>
<tr><td width="25%"><b>Address</b></td><td width="25%"><?php echo $addr;?></td></tr>
<tr><td width="25%"><b>Phone No.</b></td><td width="25%"><?php echo $phno;?></td></tr>
<tr><td width="25%"><b>Email ID</b></td><td width="25%"><?php echo $email;?></td></tr>
<tr><td width="25%"><b>Date of Birth</b></td><td width="25%"><?php echo $dob;?></td></tr>
<tr><td width="25%"><b>Guardian's Name</b></td><td width="25%"><?php echo $gname;?></td></tr>
<tr><td width="25%"><b>Guardian's Phone No.</b></td><td width="25%"><?php echo $gphno;?></td></tr>
<tr><td width="25%"><b>Member Type</b></td><td width="25%"><?php echo $atype;?></td></tr>
<tr><td width="25%"><b>Occupation</b></td><td width="25%"><?php echo $occup;?></td></tr>
<tr><td width="25%"><b>Hostel</b></td><td width="25%"><?php echo $building;?></td></tr>
<tr><td width="25%"><b>Room No.</b></td><td width="25%" style="text-transform:uppercase"><?php echo $room_no;?></td></tr>
<tr><td width="25%"><b>Application Status</b></td><td width="25%"><?php echo $app_status;?></td></tr>
<tr><td width="25%"><b>Date of Approval</b></td><td width="25%"><?php echo $doapp;?></td></tr>
<tr><td width="25%"><b>Account Status</b></td><td width="25%"><?php echo $mem_status;?></td></tr>
<tr><td width="25%"><b>Authorized Signature</b></td><td width="25%"></td></tr>
</table>
<p align="center">
*Bring the application form at the time of 1st payment. Payment must be done within 5 working days from the date of approval.
<p>
<p></p>
<center><button onclick="myFunction()">Print</button></center>
<p></p>
<center><a href="index.php">Home</a></center>
</body>
</html>