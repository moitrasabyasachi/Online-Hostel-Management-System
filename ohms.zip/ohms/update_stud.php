<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Student Portal | Update Student</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li><a href="stud_info.php"><i class="glyphicon glyphicon-user"> </i>Student Information</a></li>										
					<li><a class="active" href="update_stud.php"><i class="glyphicon glyphicon-user"> </i>Update Student</a></li>
					<li><a href="del_stud.php"><i class="glyphicon glyphicon-user"> </i>Delete Student</a></li>
					<li><a href="stud_pay_info.php"><i class="glyphicon glyphicon-credit-card"> </i>Payment Portal</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Student Portal</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Update Student</h3>					
				</div>
				<form action="update_stud.php" method="post">
				<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Member ID:</font><br>
							<select id="mem_id" name="mem_id">
								<option value="select" selected>-- Select --</option>
								
							<?php
							
							//student member ids
							
							include("connec.php");	//database parameters

							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 

							$sql = "SELECT mem_id FROM member_master where mem_id<>0 and atype='Student' and app_status='APPROVED' and mem_status<>'LEFT'";
							$result = $conn->query($sql);
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo '<option value="'.$row['mem_id'].'">'.$row['mem_id'].'</option>';
								}	
								
							} else {
								//echo "";
							}
							$conn->close();
							?>
								
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
				</div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Submit">
					</div>
				</center>
				</form>
				
			<!-- student search starts -->
			<?php
			if(isset($_POST['submit']) && $_POST['mem_id']!="select") {
				
				include("connec.php");	//database parameters

				$mem_id=$_POST["mem_id"];				

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}

				$sql = "SELECT * FROM member_master where mem_id=$mem_id";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {    
					// output data of each row
					while($row = $result->fetch_assoc()) {
						$mem_id=$row["mem_id"];
						$mem_name=$row["mem_name"];
						$addr=$row["addr"];
						$phno=$row["phno"];
						$email=$row["email"];	
						$dob=$row["dob"];
						$gname=$row["gname"];	
						$gphno=$row["gphno"];
						//$atype=$row["atype"];	
						$occup=$row["occup"];
						$gender=$row["gender"];
						$room_no=$row["room_no"];						
					}	
				} else {
					//echo "Record not found";
				}

				$conn->close();
			}
			?>
			<!-- student search ends -->
				
				<br>
				<br>
				<br>
				<form action="update_stud.php" method="post">					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<input type="hidden" id="mem_id" name="mem_id" value="<?php if(isset($_POST['submit'])){echo $mem_id;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							Name:<br>
							<input type="text" id="mem_name" name="mem_name" value="<?php if(isset($_POST['submit'])){echo $mem_name;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Address:<br>
							<textarea id="addr" name="addr" required=""><?php if(isset($_POST['submit'])){echo $addr;} ?></textarea>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Contact no.:<br>
							<input type="number" id="phno" name="phno" value="<?php if(isset($_POST['submit'])){echo $phno;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Email id:<br>
							<input type="email" id="email" name="email" value="<?php if(isset($_POST['submit'])){echo $email;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Date of Birth:<br>
							<input type="text" id="dob" name="dob" value="<?php if(isset($_POST['submit'])){echo $dob;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							Guardian's Name:<br>
							<input type="text" id="gname" name="gname" value="<?php if(isset($_POST['submit'])){echo $gname;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Guardian's phone no.:<br>
							<input type="number" id="gphno" name="gphno" value="<?php if(isset($_POST['submit'])){echo $gphno;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Occupation:<br>
							<input type="text" id="occup" name="occup" value="<?php if(isset($_POST['submit'])){echo $occup;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Gender:<br>
							<input type="text" id="gender" name="gender" value="<?php if(isset($_POST['submit'])){echo $gender;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Room no.:<br>							
							<input type="text" id="room_no" name="room_no" value="<?php if(isset($_POST['submit'])){echo $room_no;} ?>" style="text-transform:uppercase">
							<input type="hidden" id="room_no_2" name="room_no_2" value="<?php if(isset($_POST['submit'])){echo $room_no;} ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<center>
					<div class="send">
						<input type="submit" id="update" name="update" value="Update">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->

			<!-- update student profile starts -->
			<?php					
			if(isset($_POST['update'])) {
			
			include("connec.php");	//database parameters			
			
			$mem_id=$_POST["mem_id"];
			$mem_name=$_POST["mem_name"];
			$addr=$_POST["addr"];
			$phno=$_POST["phno"];
			$email=$_POST["email"];	
			$dob=$_POST["dob"];
			$gname=$_POST["gname"];	
			$gphno=$_POST["gphno"];
			//$atype=$_POST["atype"];	
			$occup=$_POST["occup"];
			$gender=$_POST["gender"];
			$room_no=$_POST["room_no"];
			$room_no_2=$_POST["room_no_2"];
			
			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$tsql = "SELECT * FROM room where room_no='$room_no'";
			$tresult = mysqli_query($conn, $tsql);

			if (mysqli_num_rows($tresult) > 0) {
				// output data of each row						
				while($row = mysqli_fetch_assoc($tresult)) {									
					$beds_taken=intval($row["beds_taken"]);								
				}
			} else {
				//echo "";
			}
			
			$tsql2 = "SELECT * FROM room where room_no='$room_no_2'";
			$tresult2 = mysqli_query($conn, $tsql2);

			if (mysqli_num_rows($tresult2) > 0) {
				// output data of each row						
				while($row = mysqli_fetch_assoc($tresult2)) {									
					$beds_taken_2=intval($row["beds_taken"]);								
				}
			} else {
				//echo "";
			}

			$sql = "UPDATE member_master SET mem_name='$mem_name',addr='$addr',phno='$phno',email='$email',dob='$dob',gname='$gname',gphno='$gphno',occup='$occup',gender='$gender',room_no='$room_no' WHERE mem_id=$mem_id";
			$sql2 = "UPDATE room SET beds_taken=$beds_taken+1 WHERE room_no='$room_no'";
			$sql3 = "UPDATE room SET beds_taken=$beds_taken_2-1 WHERE room_no='$room_no_2'";
			
			if ($conn->query($sql) === TRUE) {
				
				if($room_no!=$room_no_2){
					$conn->query($sql2);
					$conn->query($sql3);
				}
				
				echo "<p align='center'>profile edited successfully.....</p>";
			} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
			
			}
			?>
			<!-- update student profile ends -->

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>