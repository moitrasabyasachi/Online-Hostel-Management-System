<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Successful Registration</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>		
</div>	
<!--banner end here-->

<!--add member start here-->
<?php
		
	if(isset($_POST['submit'])){
	
	include("connec.php");	//database parameters
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$dor=$_SESSION["dor"];
	$mem_id=$_SESSION["mem_id"];
	$mem_name=$_SESSION["mem_name"];
	$addr=$_SESSION["addr"];
	$phno=$_SESSION["phno"];
	$email=$_SESSION["email"];	
	
	$source=$_SESSION["dob"];	
	$dob=date('d/m/Y', strtotime($source));	
	$dob2=date('dmY', strtotime($source));	
	
	$gname=$_SESSION["gname"];	
	$gphno=$_SESSION["gphno"];
	$atype=$_SESSION["atype"];	
	$occup=$_SESSION["occup"];
	$gender=$_SESSION["gender"];
	$room_no=$_SESSION["room_no"];
	$mem_uname='OHMS-'.$mem_id;
	
	$tmem_pass='OHMS-'.$mem_id.'-'.$dob2;
	$mem_pass=md5($tmem_pass,TRUE);
	
	$pic="blank-image.png";
	$app_status="PENDING";
	$mem_status='';
	
	$otp=$_POST["otp"];
	$otp2=$_POST["otp2"];
	
	$doapp='';
	$doact='';
	$dodeact='';
	$dol='';
	
if($otp==$otp2)
{
	$sql = "INSERT INTO member_master VALUES ($mem_id,'$mem_name','$addr','$phno','$email','$dob','$gname','$gphno','$atype','$occup','$gender','$room_no','$mem_uname','$mem_pass','$pic','$app_status','$mem_status')";
	
				$tsql = "SELECT * FROM room where room_no='$room_no'";
				$tresult = mysqli_query($conn, $tsql);

				if (mysqli_num_rows($tresult) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($tresult)) {									
								$beds_taken=intval($row["beds_taken"]);								
						}
				} else {
					//echo "";
				}
	
	$sql2 = "UPDATE room SET beds_taken=$beds_taken+1 WHERE room_no='$room_no'";	
	//$sql3 = "CREATE TABLE member_$mem_id (pay_id VARCHAR(100) PRIMARY KEY,mem_name VARCHAR(100),mem_id VARCHAR(100),atype VARCHAR(100),occup VARCHAR(100),room_no VARCHAR(100),fee_type_mon VARCHAR(100),fee_amt VARCHAR(100),date VARCHAR(100))";
	$sql4 = "INSERT INTO member_dates VALUES ($mem_id,'$dor','$doapp','$doact','$dodeact','$dol')";
	
	if ($conn->query($sql) === TRUE) {
			$conn->query($sql2);
			//$conn->query($sql3);
			$conn->query($sql4);
			echo '
			<div class="about">
				<div class="container">
					<div class="about-main">
						<div class="about-top">
							<h2>Successfully registered</h2>
							<h3>Application ID: <b>OHMS-'.$mem_id.'</b></h3>
							<h3>Password: <b>'.$tmem_pass.'</b></h3>
							<h3>Application Status: <b>'.$app_status.'</b></h3>
							<br>
							<p><font color="red">*Please remember your Application ID and Password</font></p>
							<a href="index.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> OHMS Home</a>
						<p> </p>
						</div>			
					</div>
				</div>
			</div>
			';
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
else
{
	echo '
			<div class="about">
				<div class="container">
					<div class="about-main">
						<div class="about-top">							
						<p>Sorry, the OTP does not match</p>
						<p> </p>
						</div>			
					</div>
				</div>
			</div>
		';
}

	// remove all session variables
	session_unset(); 

	// destroy the session 
	session_destroy();

	$conn->close();	
	}
?>
<!--add member end here-->

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>