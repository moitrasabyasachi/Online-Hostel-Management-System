<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Member's Area</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript">
function myFunction() 
{
	var x = document.getElementById("pass");
    
	if (x.type === "password") 
	{
        x.type = "text";
    } 
	else 
	{
        x.type = "password";
    }
}
</script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a class="active" href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Log In</h3>
					<p><font size="5">[</font><font size="5" face="impact">Member's Area</font><font size="5">]</font></p>
				</div>
				 <form action="#" method="post">
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							Application ID:
							<input type="text" name="uname" style="text-transform:uppercase">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Password:
							<input type="password" id="pass" name="pass"><br>
							<input type="checkbox" onclick="myFunction()">Show Password
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<!-- <textarea name="Message" placeholder="Message" required=""></textarea>-->
					<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="LOG IN">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->
<br><center><a href="fpass.php">Forgot Password</a></center>
<?php
		
	//member authentication
	
	if(isset($_POST['submit'])){
	
	include("connec.php");	//database parameters

	$u=$_POST["uname"];
	$p=md5($_POST["pass"],TRUE);
	//$p2=hex2bin($p);

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "SELECT * FROM member_master where mem_uname='$u'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {        
			$user = $row["mem_uname"];
			
			$pwd = $row["mem_pass"];
			//$pwd2=hex2bin($pwd);
			
			$mem_name = $row["mem_name"];
			$mem_id = $row["mem_id"];
			$pic = $row["pic"];
			$app_status=$row["app_status"];
			$mem_status=$row["mem_status"];
			//echo $d;
		}
	
		$_SESSION["un"] = $u;
		//$_SESSION["pd"] = $pwd;
		//$_SESSION["mname"] = $mem_name;
		$_SESSION["mid"] = $mem_id;
		//$_SESSION["photo"] = $pic;
	
		if($p==$pwd)
		{
			if($app_status=='APPROVED')
			{
				if($mem_status=='INACTIVE')
				{
					echo '<script language="javascript">';
					echo 'alert("Your account has not been activated yet.....\nPlease complete your payment.")';
					echo '</script>';
				}
				if($mem_status=='ACTIVE')
					header('Location: mem_home.php') ;			
				if($mem_status=='DEACTIVE')
				{
					echo '<script language="javascript">';
					echo 'alert("Your account has been deactivated.....\nPlease make your payment.")';
					echo '</script>';
				}
				if($mem_status=='LEFT')
				{
					echo '<script language="javascript">';
					echo 'alert("You are not a member any more.....")';
					echo '</script>';
				}
			}
			else
			{
				echo '<script language="javascript">';
				echo 'alert("Your application is pending for approval")';
				echo '</script>';
			}
		}  
		else
		{
			echo '<script language="javascript">';
			echo 'alert("Invalid user-name and password.....")';
			echo '</script>';
			//echo '<p align="center">Invalid user-name and password.....</p>';
			
			// remove all session variables
			session_unset(); 

			// destroy the session 
			session_destroy();
		}
	} else {
		echo '<script language="javascript">';
		echo 'alert("Invalid user-name and password.....")';
		echo '</script>';
		//echo '<p align="center">Invalid user-name and password.....</p>';
		
		// remove all session variables
		session_unset(); 

		// destroy the session 
		session_destroy();
	}

	$conn->close();	
	}
?>

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>