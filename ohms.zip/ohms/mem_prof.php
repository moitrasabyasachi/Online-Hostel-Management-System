<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_member.php') ;
else
{
$mem_id=$_SESSION['mid'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id='$mem_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mem_name=$row['mem_name'];
		$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Member | Profile | View Profile</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<style>
.image 
{
    border: 3px solid;
    border-color: #daeff1;
    height: 100px;
    margin: 0.5rem 0;
	width: 100px;
}
</style>
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php echo "<img class='image' src='uploads/".$pic."'/><span><font size='6' color='white'>&nbsp;".$mem_name."</font></span>";?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li></li>
					<li><a class="active" href="mem_prof.php"><i class="glyphicon glyphicon-user"> </i>View Profile</a></li>
					<li><a href="edit_prof.php"><i class="glyphicon glyphicon-user"> </i>Edit Profile</a></li>					
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="mem_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Profile</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    	
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<!--<div class="contact-top">					
					<h3>Registration Form</h3>					
				</div>-->
				
				<?php
	
				//member details
				
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM member_master where mem_id='$mem_id' ";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
							$mem_id=$row["mem_id"];
							$mem_name=$row["mem_name"];
							$addr=$row["addr"];
							$phno=$row["phno"];
							$email=$row["email"];	
							$dob=$row["dob"];
							$gname=$row["gname"];	
							$gphno=$row["gphno"];
							$atype=$row["atype"];	
							$occup=$row["occup"];
							$gender=$row["gender"];
							$room_no=$row["room_no"];

							$sql2 = "SELECT * FROM room where room_no='$room_no'";
							$result2 = mysqli_query($conn, $sql2);
				
							if (mysqli_num_rows($result2) > 0) {
								// output data of each row						
								while($row = mysqli_fetch_assoc($result2)) {								
									$building=$row["building"];								
								}
							} else {
								//echo "";
							}
								
						}
				} else {
					//echo "";
				}

				mysqli_close($conn);
	
				?>
				
				<div class="table-users">
				<table align="center">				
				<tr><th><b>Member ID:</b></th><td><?php echo $mem_id; ?></td></tr>
				<tr><th><b>Name:</b></th><td><?php echo $mem_name; ?></td></tr>
				<tr><th><b>Address:</b></th><td><?php echo $addr; ?></td></tr>
				<tr><th><b>Contact No.:</b></th><td><?php echo $phno; ?></td></tr>
				<tr><th><b>Email id:</b></th><td><?php echo $email; ?></td></tr>
				<tr><th><b>Date of Birth:</b></th><td><?php echo $dob; ?></td></tr>
				<tr><th><b>Guardian's Name:</b></th><td><?php echo $gname; ?></td></tr>
				<tr><th><b>Guardian's Phone No.:</b></th><td><?php echo $gphno; ?></td></tr>
				<tr><th><b>Member Type:</b></th><td><?php echo $atype; ?></td></tr>
				<tr><th><b>Occupation:</b></th><td><?php echo $occup; ?></td></tr>
				<tr><th><b>Gender:</b></th><td><?php echo $gender; ?></td></tr>
				<tr><th><b>Room No.:</b></th><td><?php echo $room_no; ?></td></tr>
				<tr><th><b>Building:</b></th><td><?php echo $building; ?></td></tr>
				</table>
				</div>
			</div>			
		</div>
<!--contact end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>