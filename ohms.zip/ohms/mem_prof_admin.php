<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
else
{
$fname=$_SESSION["fname"];

if($fname=="stud_info_inact.php")
{	
	$fn="Student Portal";
	$fn1="Student Information";
	$fn2="Inactive Students";
	$fn3="Student Profile";
}
else if($fname=="stud_info_act.php")
{	
	$fn="Student Portal";
	$fn1="Student Information";
	$fn2="Active Students";
	$fn3="Student Profile";
}
else if($fname=="stud_info_deact.php")
{	
	$fn="Student Portal";
	$fn1="Student Information";
	$fn2="Deactive Students";
	$fn3="Student Profile";
}
else if($fname=="stud_info_left.php")
{	
	$fn="Student Portal";
	$fn1="Student Information";
	$fn2="Students Left";
	$fn3="Student Profile";
}

else if($fname=="staff_info_inact.php")
{	
	$fn="Staff Portal";
	$fn1="Staff Information";
	$fn2="Inactive Staffs";
	$fn3="Staff Profile";
}
else if($fname=="staff_info_act.php")
{	
	$fn="Staff Portal";
	$fn1="Staff Information";
	$fn2="Active Staffs";
	$fn3="Staff Profile";
}
else if($fname=="staff_info_deact.php")
{	
	$fn="Staff Portal";
	$fn1="Staff Information";
	$fn2="Deactive Staffs";
	$fn3="Staff Profile";
}
else if($fname=="staff_info_left.php")
{	
	$fn="Staff Portal";
	$fn1="Staff Information";
	$fn2="Staffs Left";
	$fn3="Staff Profile";
}

else
{
	$fn="#";
	$fn1="#";
	$fn2="#";
}
}
?>

<!DOCTYPE HTML>
<html>
<head>
<!--<title>OHMS | Admin | <?php //echo $fn;?> | <?php //echo $fn1;?> | <?php //echo $fn2;?></title>-->
<title>OHMS | Member Profile</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<style>
.image 
{
    border: 3px solid;
    border-color: #daeff1;
    height: 100px;
    margin: 0.5rem 0;
	width: 100px;
}
</style>
</head>
<body style="background-color:white;">

<?php
$mid=$_POST['mem_id'];
?>

<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
				<?php
					include("logo.html");
				?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li></li>
					<li><a class="active" href="mem_prof.php"><i class="glyphicon glyphicon-user"> </i>View Profile</a></li>
					<li><a href="edit_prof.php"><i class="glyphicon glyphicon-user"> </i>Edit Profile</a></li>					
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="<?php echo $fname;?>" class="btn btn-link" role="button">Back</a></div>
	<!--<div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a></div>-->
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>		
    <div class="col-md-1"><!--<a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a>--></div>
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Member Profile</h3>					
				</div>
				
				<?php
	
				//member details
				
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM member_master where mem_id=$mid";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row						
						while($row = mysqli_fetch_assoc($result)) {								
							$pic=$row["pic"];
							$mem_id=$row["mem_id"];
							$mem_name=$row["mem_name"];
							$addr=$row["addr"];
							$phno=$row["phno"];
							$email=$row["email"];	
							$dob=$row["dob"];
							$gname=$row["gname"];	
							$gphno=$row["gphno"];
							$atype=$row["atype"];	
							$occup=$row["occup"];
							$gender=$row["gender"];
							$room_no=$row["room_no"];
							$mem_status=$row["mem_status"];

							$sql2 = "SELECT * FROM room where room_no='$room_no'";
							$result2 = mysqli_query($conn, $sql2);
				
							if (mysqli_num_rows($result2) > 0) {
								// output data of each row						
								while($row = mysqli_fetch_assoc($result2)) {								
									$building=$row["building"];								
								}
							} else {
								//echo "";
							}
							
							$dor='N/A';
							$doapp='N/A';
							$dol='N/A';
							
							$sql3 = "SELECT * FROM member_dates where mem_id=$mem_id";
							$result3 = mysqli_query($conn, $sql3);
				
							if (mysqli_num_rows($result3) > 0) {
								// output data of each row						
								while($row = mysqli_fetch_assoc($result3)) {								
									$dor=$row["dor"];
									$doapp=$row["doapp"];
									$dol=$row["dol"];								
								}
							} else {
								//echo "";
							}
								
						}
				} else {
					//echo "";
				}

				mysqli_close($conn);
	
				?>
				
				<div class="table-users">
				<table align="center">				
				<tr><td colspan="2"><?php echo "<center><img class='image' src='uploads/".$pic."'/></center>"; ?></td></tr>
				<tr><th><b>Date of Registration:</b></th><td><?php echo $dor; ?></td></tr>
				<tr><th><b>Date of Approval:</b></th><td><?php echo $doapp; ?></td></tr>
				<tr><th><b>Member ID:</b></th><td><?php echo $mem_id; ?></td></tr>
				<tr><th><b>Name:</b></th><td><?php echo $mem_name; ?></td></tr>
				<tr><th><b>Address:</b></th><td><?php echo $addr; ?></td></tr>
				<tr><th><b>Contact No.:</b></th><td><?php echo $phno; ?></td></tr>
				<tr><th><b>Email id:</b></th><td><?php echo $email; ?></td></tr>
				<tr><th><b>Date of Birth:</b></th><td><?php echo $dob; ?></td></tr>
				<tr><th><b>Guardian's Name:</b></th><td><?php echo $gname; ?></td></tr>
				<tr><th><b>Guardian's Phone No.:</b></th><td><?php echo $gphno; ?></td></tr>
				<tr><th><b>Member Type:</b></th><td><?php echo $atype; ?></td></tr>
				<tr><th><b>Occupation:</b></th><td><?php echo $occup; ?></td></tr>
				<tr><th><b>Gender:</b></th><td><?php echo $gender; ?></td></tr>
				<tr><th><b>Room No.:</b></th><td><?php echo $room_no; ?></td></tr>
				<tr><th><b>Building:</b></th><td><?php echo $building; ?></td></tr>
				<tr><th><b>Status:</b></th><td><?php echo $mem_status; ?></td></tr>
				<tr><th><b>Date Left:</b></th><td><?php echo $dol; ?></td></tr>
				</table>
				</div>
			</div>			
		</div>
<!--contact end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>