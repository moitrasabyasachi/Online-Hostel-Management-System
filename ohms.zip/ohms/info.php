<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | New Member</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php include("logo.html");	?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a class="active" href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>	
</div>	
<!--banner end here-->
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Rules & Regulations</h2>
				<p> </p>
			</div>
			<div class="row">
				<div class="col-md-12">
				<p align="justify">				
				1. 	Students are expected to act in such a manner that an atmosphere conducive to effective study prevails in the hostel.<br>				
				2. 	Students are required to be aware of all notices that are put up on the Notice Boards.<br>
				3. 	The hostel wardens have full authority to check any room in the hostel at any time with or without the help from local administration.<br>
				4. 	Ragging is a cognizable offence, punishable under the law and is strictly banned. Any student involved in any kind of ragging will be liable for immediate expulsion from the hostel/college.<br>
				5. 	Possession of fire arms, daggers, cycle chains, rods, iron rods or any other kind of weapons are strictly prohibited (Arms Acts.). Hostel inmates found in possession of the above will be handed over to the police or expelled from hostel immediately. No inquiry into the matter shall be required.<br>
				6. 	No one is allowed to take part in any type of video film show in the hostel premises without the permission of the hostel warden.<br>
				7. 	Unauthorized guests or outsiders in the hostel room are strictly prohibited. Any student keeping unauthorized person in his/her room will be liable to disciplinary action amounting to expulsion from the hostel. Guest may be allowed on prior written permission of the warden.<br>
				8. 	No student shall occupy or interchange the room without permission and proper allotment of the room by hostel warden.<br>
				9.	Consumption of alcohol and other intoxicants and drugs are strictly prohibited. Anyone found consuming alcohol or drugs will be expelled from the hostel immediately. No enquiry into the matter shall be required.<br>
				10.	Cooking food in the hostel room is strictly prohibited. In order to avoid fire hazards, no fire producing equipment in the room is permitted.<br>
				11.	Hostellers are warned not to keep valuable goods in their rooms. Hostel management shall not be responsible for loss of such valuables.<br>
				12. Students shall have to abide by the decisions of the hostel wardens with respect to enforcement of the hostel rules failing which strict disciplinary action may be taken.<br>
				13. While leaving the rooms, it must be ensured that the light and fans are switched off failing which he/she will be liable to imposition of fines.<br>
				14. Use of electrical appliances such as heaters, electrical irons etc. are strictly prohibited. Violation of this rule will lead to strict disciplinary action. Confiscation along with a fine of Rs. 500/- shall be imposed.<br>
				15. Tampering with and alteration of electrical fittings are strictly prohibited and liable for action.<br>
				16.	Hostellers desiring to go out of station must obtain permission from the warden concerned before going out.<br>
				17.	Damage to hostel property such as doors, windows, electrical fitting, toilet fitting, glass panes etc. will lead to fine, disciplinary action, expulsion from the hostel. A general deduction from the hostel security deposit will be made at the end of the course, towards the breakage other than those, which are charged against the individuals.<br>
				18.	No permission shall be given to a student to stay in the hostel after his/her even semester examinations are over, and for the purpose of preparation or appearance in any entrance test or any competitive examination he/she must obtain permission from the warden.<br>
				19.	The boarders must keep their rooms neat and clean. They have to use waste paper baskets of their own in their rooms. Any waste found in hostel lobby is likely to get it cleaned by the residents of the lobby and a fine shall be realized from the residents in a combined manner as deemed fit by the hostel management.<br>
				20.	Each boarder should check the fittings in his room at the time of occupation and takeover of the fittings and furniture in writing which are returnable on vacation of the room. Any loss or damage will be borne by the concerned boarder or boarders.<br>
				21.	Room furniture, electric fittings etc are required to be maintained by the students in good conditions. At the time of allotment of seat / leaving the hostel for Summer Vacation every student must take over / handover the hostel room properly and carefully. They shall not break or damage any furniture and fittings. If any breakage occurs then cost will be realized (individually or collectively), together with heavy fines imposed on them.<br>
				22.	Private picnics are prohibited in principle. The boarders are therefore cautioned against arranging picnic of their own without the written permission of the Wardens.<br>
				23.	Student shall not remain absent from their hostels during the night between 10.00 P.M. to 5.00 A.M. without prior permission of the warden.<br>
				24.	Student shall not remain absent from their hostels during the night between 10.00 P.M. to 5.00 A.M. without prior permission of the warden.<br>
				25.	Female visitors are not permitted at any time into the Hostels for boys. Parents Visitors may take prior reservation from Chief Warden to stay in Institute Guest House/ Guest House on payment.<br>
				26.	Boarders shall not leave the hostel without prior permission of the warden they shall apply to the Warden/Chief Warden stating reason of leaving and address of destination. Boarders who leave without application and permission shall be deemed to be missing and Police authorities / parents may be intimated as such.<br>
				27.	Boarders will be personally / collectively responsible for any loss or damage caused to the properties and equipment and other fittings in the common places, due to indiscipline.<br>
				28.	College will not be responsible for acts of student which lead to the disturbance of public peace and tranquility or cases of Law and Order in which they are knowingly or unknowingly involved in or outside the College premises.<br>
				29.	Any boarder harboring any unauthorized element or any one expelled / removed from hostel earlier or any outside element, will be punished which nay be up to removal from Hostels / College.<br>
				30.	Boarders shall treat their fellow boarders, institute staff, hostel staff, mess staff with dignity and decorum.<br>
				31.	Non-regular and Non-collegiate students having filled up form to appear at examination may be allowed to stay in the hostel temporarily, vacancy permitting, only if they obtain prior written permission of the authorities and undertake to abide by the hostel rules and deposit the fees of hostels in advance.<br>
				32.	Students belonging to above categories willing to appear at their back-paper examinations may be allowed temporary accommodation in hostel not exceeding two months at a time on payment of usual charges for food and accommodation to the hostel in advance, subject to satisfying other conditions.<br>
				33.	Ex-students, if allotted room temporarily will have to pay in advance seat-rent and electricity charges at the rate Rs. 20/- per day per head or Rs. 500/- per month whichever is less. Such allot tees cannot claim provision of furniture if not available in the hostel.<br>
				34.	Students/Delegates from other organizations may be allowed temporary accommodation in hostel with permission from the Warden/Chief Warden/Director, for which they may have to pay usual temporary accommodation charges.<br>
				35.	No notice shall be put in the Hostel by any student directly unless such permission has been granted by the Warden of respective hostels.<br>
				36.	No student or students shall raise or assist others to raise any subscription in the Hostel on any account without prior permission of the authorities.<br>
				37.	Each boarder will be completely responsible for his/her belongings. The Institute will not be responsible for loss incurred due to his negligence or any other reason whatsoever.<br>
				38.	Students must not keep valuable in their rooms. Extra money must be deposited in the post office/savings bank account. They should lock their rooms properly when they go out for bath, etc.<br>
				39.	No one should use the belongings of other students without their consent.<br>
				40.	Employment of personal servant or attendant in a hostel is not allowed.<br>
				41.	Each student must carry identity card whenever he/she goes outside the hostel and produce on demand from institute/Hostel authorities otherwise a fine or disciplinary actions might be taken.<br>
				42.	Residents desirous of purchasing second hand bicycle, calculator, mobiles, computers etc should ensure about the authenticity of the owner to avoid purchase of stolen and incriminating items.<br>
				43.	Boarders are not to patronize food/soft drinks/snacks from unhygienic shops and road-side vendors to avoid infection to themselves and spreading amongst fellow boarders.<br>
				44.	The boarders must be very particular about payment of hostel dues/Institute fees. The Accounts Section shall accept the Institute fees only after production of up to date mess dues clearance from the hostel. For payment of dues only two chances shall be given, the first without fine and the second with fine.<br>
				45.	A student must remember that the hostel is the home of the students on the campus, he/she should behave himself/herself on the campus as well as outside in such manner as to bring credit to him/her and to the Institute.<br>
				46.	A student once admitted in the hostel continues to be a hostel inmate throughout the year. He/she has to pay the room rent for the full academic session. The amount will be forfeited if the inmate decides to leave the hostel in the mid-session.<br>
				47.	Every student should stay in the accommodation allotted to him/her by the Warden concerned. He/she will not be allowed to change the accommodation once allotted.<br>
				48.	A student should not enter the rooms of others who are not in their rooms.<br>
				49.A student shall not hand over the keys of his/her room to any other student/person except the Warden or person authorized by him.<br>				
				</p>
				</div>				
			</div>						
		</div>
	</div>
</div>


	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Fees Structure</h2>
				<p> </p>
			</div>
			<div class="row">
				<div class="col-md-12">
				<p>				
					<div class="table-users" style="width:100%;">
					<table align="center">	
						<tr>
							<td colspan="2"><center><b>FOR STUDENTS</b></center></td>
						</tr>
						<tr>
							<td align="center"><b>Occupation</b></td>
							<td><center><b>Amount to be paid per Month</b></center></td>
						</tr>
						
				<?php
				
				//fees structure for students
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM stud_fee_struc";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$occup=$row["occup"];
						$fee_per_month=$row["fee_per_month"];
						
						echo "<tr><td>".$occup."</td><td><center>Rs.".$fee_per_month."</center></td></tr>";
					}
				}else {
					//echo "<center>Nothing to display</center>";
				}

				mysqli_close($conn);
	
				?>
				</table>
				</div>
						<div class="table-users" style="width:100%;">
						<table align="center">
						<tr>
							<td colspan="2"><center><b>FOR STAFFS</b></center></td>
						</tr>
						<tr>
							<td align="center"><b>Occupation</b></td>
							<td><center><b>Amount to be paid per Month</b></center></td>							
						</tr>
				
				<?php
	
				//fees structure for staffs
	
				include("connec.php");	//database parameters

				// Create connection
				$conn = mysqli_connect($servername, $username, $password, $dbname);
				// Check connection
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
	
				$sql = "SELECT * FROM staff_fee_struc";				
				
				$result = mysqli_query($conn, $sql);				

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while($row = mysqli_fetch_assoc($result)) {								
						$occup=$row["occup"];
						$fee_per_month=$row["fee_per_month"];						
						
						echo "<tr><td>".$occup."</td><td><center>Rs.".$fee_per_month."</center></td></tr>";
					}
				}else {
					//echo "<center>Nothing to display</center>";
				}

				mysqli_close($conn);
	
				?>
					</table>
					</div>
				</p>
				</div>
			</div>
		</div>
	</div>	
<div class="about">	
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<a href="regform.php" class="btn btn-info" role="button">Proceed</a>
			</div>									
		</div>
	</div>
</div>
<!--about end here-->
<!--testimonial start here-->
<!--<div class="testimonial">
	<div class="container">
		<div class="testimonial-main">
			<h3>Testimonial</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		</div>
	</div>
</div>
<!--testimonial end here-->
<!--team start here-->
<!--<div class="team">
	<div class="container">
		<div class="team-main">
			<div class="team-top" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInDown;">
				<h3>Volunteers</h3>
				
			</div>
			<div class="team-bottom" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;">
			  <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t1.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Malorum</h3>		          
			          </div>			          
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			        
			    <!-- end normal -->
			   <!--</div>
			  <div class="col-md-3 team-grids">
			   <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t2.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Bonorum</h3>		           	            
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->		 
			  <!--</div>
			  <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t3.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Finibus</h3>			       
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->
			  <!--</div>
			   <div class="col-md-3 team-grids">
			    <!-- normal -->
			    <!--<div class="ih-item circle effect5"><a href="#">
			        <div class="img"><img src="images/t4.jpg" alt="img" class="img-responsive"></div>
			        <div class="info">
			          <div class="info-back">
			            <h3>Rackham</h3>		           
			          </div>
			        </div></a></div>
			        <div class="team-bottom">
			        	  <p>On the other hand, we denounce with righteous indignation.</p>
			        	  <ul>
			        	  	<li><a href="#" class="fa"> </a></li>
			        	  	<li><a href="#" class="tw"> </a></li>
			        	  	<li><a href="#" class="g"> </a></li>
			        	  </ul>
			        </div>
			    <!-- end normal -->			 
			  <!--</div>
			</div>
		</div>
	</div>
</div>
<!--team end here-->
<!--footer start here-->
<!--<div class="footer">
	<div class="container">
		<div class="footer-main">
			<div class="col-md-4 ftr-grid">
				<h3>Navigation</h3>
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="shortcodes.html">Short Codes</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</div>
			<div class="col-md-4 ftr-grid">
				<h3>Latest Tweet</h3>
				<div class="tweets">
					<div class="tweet-icon">
						<span class="tweet-img"> </span>
					</div>
					<div class="tweet-text">
						<p>Lorem ipsum</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur But I must explain to you how all this mistaken.</p>
			</div>
			<div class="col-md-4 ftr-grid">
				<h3>Keep In Touch</h3>
				<div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-map-marker">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-earphone">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>+12 894 8579</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-envelope">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p><a href="mailto:info@example.com">lorem@example.com</a></p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			</div>
			<div class="clearfix"> </div>		
		</div>
	</div>
</div>
<!--footer end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>