<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<html>
<head>
	<title></title>
</head>
<body>

<!--notice deletion-->
<?php
if(isset($_POST['del']))
{
	$not_id=$_POST["not_id"];
	
	include("connec.php");	//database parameters
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "DELETE FROM notice_board WHERE not_id=$not_id";
	
	if ($conn->query($sql) === TRUE) 
	{
		echo "<h1 align='center'>Message deleted successfully.....</h1>";			
	}
	else
	{
		
	}
	
	$conn->close();
	
	header("refresh:1;url=ind_notice.php");
}
?>

</body>
</html>