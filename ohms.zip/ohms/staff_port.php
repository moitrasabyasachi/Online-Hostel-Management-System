<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

//$fname=basename(__FILE__);
//$_SESSION["fname"] = $fname;

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Staff Portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style_divtab.css">
<link rel="stylesheet" href="css/style_button.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<!--<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #01BF07;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 20px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button:hover {
  padding-right: 40px;
   color: #FFFFFF;
   font-weight:bold;
  
}

.button:hover 
  opacity: 1;
  right: 0;
}
</style>-->

</head>
<body style="background-color:white;">
<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
				<?php
					include("logo.html");
				?>
	   </div>
	   <div class="header-icons">
		<h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->
				<ul class="res">
					<li><a href="staff_info_inact.php"><i class="glyphicon glyphicon-user"> </i>Staff Information</a></li>										
					<li><a href="update_staff.php"><i class="glyphicon glyphicon-user"> </i>Update Staff</a></li>
					<li><a href="del_staff.php"><i class="glyphicon glyphicon-user"> </i>Delete<br>Staff</a></li>
					<li><a href="staff_pay_info.php"><i class="glyphicon glyphicon-credit-card"> </i>Payment Portal</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
	  </div>
  </div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Staff Portal</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>
  </div>
</div>
<!--about start here-->
<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="about-top">
				<h2>Welcome</h2>
				<h3><font face="Comic Sans MS" color="#">to</font></h3>				
				<h2><font face="Comic Sans MS" color="#fdbd10">Staff Portal</font></h2>
			</div>		
		</div>
	</div>
</div>
<!--about end here-->
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>