<?php
	// Start the session
	session_start();
	
	$user=$_SESSION["un"];

	if($user=="")
		header('Location: login_manager.php') ;
?>

<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$mem_id=$_POST['mem_id'];
		$mem_status=$_POST['submit2'];

		include("connec.php");	//database parameters
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		
		if($mem_status=="Activate")
		{
			$doact=date('d/m/Y');
			$sql = "UPDATE member_master SET mem_status='ACTIVE' WHERE mem_id=$mem_id";
			$sql2 = "UPDATE member_dates SET doact='$doact' WHERE mem_id=$mem_id";

			if ($conn->query($sql) === TRUE) {
				echo "<h1 align='center'>Account Activated</h1>";
				$conn->query($sql2);
			} else {
				//echo "Error updating record: " . $conn->error;
			}			
			//header('Location: admin_home.php');
			header("refresh:1;url=stud_port.php");
		}
		else if($mem_status=="Deactivate")
		{
			$dodeact=date('d/m/Y');
			$sql = "UPDATE member_master SET mem_status='DEACTIVE' WHERE mem_id=$mem_id";
			$sql2 = "UPDATE member_dates SET dodeact='$dodeact' WHERE mem_id=$mem_id";

			if ($conn->query($sql) === TRUE) {
				echo "<h1 align='center'>Account Dectivated</h1>";
				$conn->query($sql2);
			} else {
				//echo "Error updating record: " . $conn->error;
			}			
			//header('Location: admin_home.php');
			header("refresh:1;url=stud_port.php");
		}
		
		$conn->close();
		
	?>
</body>
</html>