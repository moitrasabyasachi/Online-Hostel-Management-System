				<?php									
					$email=$_POST['email'];
					$npass=$_POST['npass'];
					$cpass=$_POST['cpass'];					
					
					if($npass==$cpass)
					{
						$tpass=md5($npass);
						
						include("connec.php");	//database parameters
						// Create connection
						$conn = new mysqli($servername, $username, $password, $dbname);
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						}
						
						$sql = "UPDATE member_master SET mem_pass='$tpass' WHERE email='$email'";
						
						if ($conn->query($sql) === TRUE) {
							echo "<p align='center'>Password changed successfully.....</p>";
						} else {
							//echo "Error: " . $sql . "<br>" . $conn->error;
						}
						
						header("refresh:1;url=login_member.php");

						$conn->close();
					}
					else
					{
						echo '<script language="javascript">';
						echo 'alert("Password & Confirm Password must be same")';
						echo '</script>';
					}				
				?>