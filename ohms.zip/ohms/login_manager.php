<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Manager's Area</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<ul class="res">
					<li><a class="active" href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
					<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
					<li><a href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
					<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
					<li><a href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Log In</h3>
					<p><font size="5">[</font><font size="5" face="impact">Admin's Area</font><font size="5">]</font></p>
				</div>
				 <form action="login_manager.php" method="post">
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<input type="text" id="uname" name="uname" placeholder="Enter your login id">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							<input type="password" id="pass" name="pass" placeholder="Enter your password">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<!-- <textarea name="Message" placeholder="Message" required=""></textarea>-->
					<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="LOG IN">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->

<?php

//admin authentication
		
	if(isset($_POST['submit'])){
	
	include("connec.php");	//database parameters

	$u=$_POST["uname"];
	$p=$_POST["pass"];

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "SELECT * FROM admin where uname='$u' and pass='$p'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {        
			$user = $row["uname"];
			$pwd = $row["pass"];        
			//echo $d;
		}
	
		$_SESSION["un"] = $user;
		$_SESSION["pd"] = $pwd;
	
		if($u==$user && $p==$pwd)
		{
			header('Location: admin_home.php') ;			
		}
  
		else
		{
			echo '<script language="javascript">';
			echo 'alert("Invalid user-name and password.....")';
			echo '</script>';
			
			// remove all session variables
			session_unset(); 

			// destroy the session 
			session_destroy();
		}
	} else {
			echo '<script language="javascript">';
			echo 'alert("Invalid user-name and password.....")';
			echo '</script>';
		
		// remove all session variables
		session_unset(); 

		// destroy the session 
		session_destroy();
	}

	$conn->close();	
	}
?>

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>