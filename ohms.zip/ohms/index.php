<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Home</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
<!-- animated-css -->
		<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
		<script src="js/wow.min.js"></script>
		<script>
		 new WOW().init();
		</script>
<!-- animated-css -->
<script src="js/responsiveslides.min.js"></script>
 <script>
    // You can also use "$(window).load(function() {"
    $(function () {
      // Slideshow 1
      $("#slider1").responsiveSlides({
         auto: true,
		 nav: true,
		 speed: 500,
		 namespace: "callbacks",
      });
    });
  </script>

</head>
<body>
<!--banner start here-->
<div class="ban-mother-grid">
<div class="slider">
		    <ul class="rslides" id="slider1">
		      <li>
		      	<div class="banner">
					
				</div>
		      </li>
		      <!--<li>
		      	<div class="banner2">
					
				</div>
		      </li>
		      <li>
		      	<div class="banner3">
					
				</div>
		      </li>-->
		    </ul>
 </div>	
<div class="header">
	<div class="container">
			   <div class="logo wow" data-wow-delay="0.3s">
				<?php
					include("logo.html");
				?>
			   </div>
			   <div class="header-icons">			   	 
			   	 	<h2 class="mystyle1"><a href="index.php"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></a></h2>
			   	 	<!--<ul>
					<li><a href="#" class="fb"> </a></li>
					<li><a href="#" class="twit"> </a></li>
			   	 	<li><a href="#" class="gmail"> </a></li>
			   	 	<li><a href="#" class="dri"> </a></li>
			   	 </ul>-->
			   </div>
			    <div class="clearfix"> </div>
    </div>	    
</div>
 <!--navgation start here-->
<div class="top-nav">
    	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->		
		<ul class="res">
			<!--<li><a class="active" href="index.html"><i class="glyphicon glyphicon-home"> </i>Home</a></li>-->			
			<li><a href="login_manager.php"><i class="glyphicon glyphicon-user"> </i>Admin's Area</a></li>
			<li><a href="login_member.php"><i class="glyphicon glyphicon-user"> </i>Existing Member</a></li>
			<li><a href="info.php"><i class="glyphicon glyphicon-user"> </i>New Member</a></li>
			<li><a href="app_status.php"><i class="glyphicon glyphicon-book"> </i>Application Status</a></li>
			<li><a href="about.php"><i class="glyphicon glyphicon-book"> </i>About OHMS</a></li>
			<!--<li><a href="blog.html"><i class="glyphicon glyphicon-picture"> </i>Blog</a></li>
			<li><a href="contact.html"><i class="glyphicon glyphicon-envelope"> </i>Contact</a></li>-->
		</ul>		
		<!-- script-for-menu -->
					 <!--<script>
					   $( "span.menu" ).click(function() {
						 $( "ul.res" ).slideToggle( 300, function() {
						 // Animation complete.
						  });
						 });
					</script>
	<!-- /script-for-menu -->
</div>	
</div>

<!--navgation end here-->
<!--banner end here-->
<!-- <div class="banner-strip">
	<div class="container">
		<div class="bann-strip-main">
			   <div class="col-md-4 bann-strip-grid">
			   	  <div class="col-md-4 b-strip-left">
			   	  	 <span class="glyphicon glyphicon-leaf hovicon effect-4 sub-b" aria-hidden="true"> </span>
			   	  </div>
			   	  <div class="col-md-8 b-strip-right">
			   	  	 <h4>Excepteur sint</h4>
			   	  	 <p>Lorem ipsum dolor sit amet, consectetur adipiscing.</p>
			   	  </div>
			   	  <div class="clearfix"> </div>
			   </div>
			   <div class="col-md-4 bann-strip-grid">
			   	  <div class="col-md-4 b-strip-left">
			   	  	 <span class="glyphicon glyphicon-eye-open hovicon effect-4 sub-b" aria-hidden="true"> </span>
			   	  </div>
			   	  <div class="col-md-8 b-strip-right">
			   	  	<h4>Excepteur sint</h4>
			   	  	<p>Lorem ipsum dolor sit amet, consectetur adipiscing.</p>
			   	  </div>
			   	  <div class="clearfix"> </div>
			   </div>
			   <div class="col-md-4 bann-strip-grid">
			   	  <div class="col-md-4 b-strip-left">
			   	  	<span class="glyphicon glyphicon-education hovicon effect-4 sub-b" aria-hidden="true"> </span>
			   	  </div>
			   	  <div class="col-md-8 b-strip-right">
			   	  	<h4>Excepteur sint</h4>
			   	  	<p>Lorem ipsum dolor sit amet, consectetur adipiscing.</p>
			   	  </div>
			   	  <div class="clearfix"> </div>
			   </div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!--vedio block start here-->
<!--<div class="vedio">
	<div class="container">
		<div class="vedio-main">
			<div class="col-md-6 vedio-left wow fadeInLeft" data-wow-delay="0.3s">
				<h2>WHO WE ARE</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
					 nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur But I must explain to you how all this mistaken
					  idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system.</p>
			</div>
			<div class="col-md-6 vedio-right wow fadeInRight" data-wow-delay="0.3s">
				<iframe src="https://player.vimeo.com/video/62534157?color=f2dc5a&amp;title=0&amp;byline=0&amp;portrait=0"></iframe>			
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
</div>
<!--vedio block end here-->
<!--charity strip start here-->
<!--<div class="charity">
	<div class="container">
		<div class="charity-main wow fadeInRight" data-wow-delay="0.3s">
			<h3>No one has ever become Poor by Giving</h3>
			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
		</div>
	</div>
</div>
<!--charity strip end here-->
<!--donate start here-->
<!--<div class="donayte">
	<div class="container">
		<div class="donate-main">
			<div class="col-md-3 donate-grid wow fadeInLeft" data-wow-delay="0.3s">
				<h3>Donate Our Charity</h3>
				<h4>On the other hand, we denounce with righteous indignation and dislike.</h4>
				<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum</p>
			</div>
			<div class="col-md-3 donate-grid wow fadeInLeft" data-wow-delay="0.3s">
				<div class="fall-down-effect top">
							<div class="img-box"><img src="images/d1.jpg" alt=""></div>
							<div class="text-box">
								<div class="text-content">
									<h3>Help</h3>																																		
								</div>
							</div>
						</div>
				<h5>Nam libero tempore</h5>	
				<p>voluptates repudiandae sint et molestiae non recusandae.</p>
			</div>
			<div class="col-md-3 donate-grid wow fadeInRight" data-wow-delay="0.3s">
				<div class="fall-down-effect top">
							<div class="img-box"><img src="images/d2.jpg" alt=""></div>
							<div class="text-box">
								<div class="text-content">
									<h3>Help</h3>																																		
								</div>
							</div>
						</div>
				<h5>Nam libero tempore</h5>		
				<p>voluptates repudiandae sint et molestiae non recusandae.</p>			
			</div>
			<div class="col-md-3 donate-grid wow fadeInRight" data-wow-delay="0.3s">
				<div class="fall-down-effect top">
							<div class="img-box"><img src="images/d3.jpg" alt=""></div>
							<div class="text-box">
								<div class="text-content">
									<h3>Help</h3>																																		
								</div>
							</div>
						</div>
				<h5>Nam libero tempore</h5>		
				<p>voluptates repudiandae sint et molestiae non recusandae.</p>
			</div>
		</div>
	</div>
</div>
<!--donate end here-->
<!--terisa block start here-->
<!--<div class="terisa">
	<div class="container">
		<div class="terisa-main">
			  <div class="col-md-6 terisa-left wow fadeInLeft" data-wow-delay="0.3s">
				<h3>Lorem ipsum dolor sit amet, consectetur</h3>
				<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				<ul>
					<li><span class="glyphicon glyphicon-star-empty" aria-hidden="true"></span><a href="#"> libero tempore, cum soluta nobis</a></li>
					<li><span class="glyphicon glyphicon-star-empty" aria-hidden="true"></span><a href="#">Nam libero tempore, cum soluta nobis</a></li>
					<li><span class="glyphicon glyphicon-star-empty" aria-hidden="true"></span><a href="#">Tempore, cum soluta nobis Nam libero</a></li>
				</ul>
			  </div>
			 <div class="col-md-6 terisa-right wow fadeInRight" data-wow-delay="0.3s">
				  <img src="images/h1.png" alt="" class="img-responsive">
			 </div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!--terisa block end here-->
<!--footer start here-->
<!--<div class="footer">
	<div class="container">
		<div class="footer-main">
			<div class="col-md-4 ftr-grid wow zoomIn" data-wow-delay="0.3s">
				<h3>Navigation</h3>
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="shortcodes.html">Short Codes</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</div>
			<div class="col-md-4 ftr-grid wow zoomIn" data-wow-delay="0.3s">
				<h3>Latest Tweet</h3>
				<div class="tweets">
					<div class="tweet-icon">
						<span class="tweet-img"> </span>
					</div>
					<div class="tweet-text">
						<p>Lorem ipsum</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur But I must explain to you how all this mistaken.</p>
			</div>
			<div class="col-md-4 ftr-grid wow zoomIn" data-wow-delay="0.3s">
				<h3>Keep In Touch</h3>
				<div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-map-marker">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-earphone">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>+12 894 8579</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-envelope">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p><a href="mailto:info@example.com">lorem@example.com</a></p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			</div>
			<div class="clearfix"> </div>		
		</div>
	</div>
</div>
<!--footer end here-->
<br>
<br>
<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main wow" data-wow-delay="0.3s">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>		 