<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<html>
<head>
	<title></title>
</head>
<body>

<!--generate individual notice start here-->
<?php
		
	if(isset($_POST['send'])){
	
	include("connec.php");	//database parameters

	$not_id=$_POST["not_id"];
	$date=$_POST["date"];
	$time=$_POST["time"];
	$mem_id=$_POST["mem_id"];	
	$sub=$_POST["sub"];
	$body=$_POST["body"];	

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
	
	$sql = "INSERT INTO notice_board VALUES ($not_id, 'admin', 0, '$sub', '$body', '$date', '$time', $mem_id)";	

	if ($conn->query($sql) === TRUE) {
			echo "<h1 align='center'>Message send successfully.....</h1>";			
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
	
	header("refresh:1;url=ind_notice.php");
	}
?>
<!--generate individual notice end here-->

</body>
</html>