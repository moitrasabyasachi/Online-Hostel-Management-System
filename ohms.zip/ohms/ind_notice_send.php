<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
else
{
$mid=$_POST['mem_id'];

include("connec.php");	//database parameters
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM member_master where mem_id=$mid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $mname=$row['mem_name'];
		//$pic=$row['pic'];
    }
} else {
    //echo "0 results";
}

$conn->close();
}
?>

<html>
<head>
<title>OHMS | Admin | Generate Notices | Individual Notices | Write Message</title>
</head>
<body>
		<!-- auto number generation starts -->		
		<?php				
		include("connec.php");	//database parameters
				
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM notice_board";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$b = $row["not_id"];
				$c=intval($b);
				//echo $d;
			}
			$r=$c+1;
		}
				
		$conn->close();
		?>
		<!-- auto number generation ends -->

<form action="ind_notice_send_2.php" method="post">
<table border="0" align="center" width="50%">
<tr><td colspan="2"><hr><?php include("logo.html");	?><font face="Impact" size="3">ONLINE HOSTEL MANAGEMENT SYSTEM</font><hr></td></tr>
<tr><td colspan="2" align="center"><input type="hidden" id="mem_id" name="mem_id" value="<?php echo $mid; ?>"></td></tr>
<tr><th colspan="2" align="center">WRITE MESSAGE<hr></th></tr>
<tr>
<td colspan="2" align="center">
<input type="hidden" id="not_id" name="not_id" value="<?php echo $r; ?>">
<input type="hidden" id="date" name="date" value="<?php echo date("d/m/Y"); ?>">
<input type="hidden" id="time" name="time" value="<?php date_default_timezone_set("asia/kolkata"); echo date("h:ia"); ?>">
</td>
</tr>
<tr><td width="25%"><b>To</b></td><td width="25%"><?php echo $mname;?></td></tr>
<tr><td width="25%"><b>Subject</b></td><td width="25%"><input type="text" id="sub" name="sub"></td></tr>
<tr><td width="25%" valign="top"><b>Body</b></td><td width="25%"><textarea rows="10" cols="25" id="body" name="body" required=""></textarea></td></tr>
<tr><td colspan="2" align="center"></td></tr>
<tr><td colspan="2" align="center"><hr><input type="submit" id="send" name="send" value="Send"><hr></td></tr>
</table>
</form>
<p></p>
<center><a href="ind_notice.php">Back</a></center>
<p></p>
<hr>

<?php
	echo "<center>";
	include("footer.html");
	echo "</center>";
?>
</body>
</html>