<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
// Start the session
session_start();

$user=$_SESSION["un"];

if($user=="")
	header('Location: login_manager.php') ;
?>

<!DOCTYPE HTML>
<html>
<head>
<title>OHMS | Admin | Room Management | Update Room</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
</head>
<body>
<!--banner start here-->
<div class="banner1">
	<div class="header">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
			<?php
				include("logo.html");
			?>
	   </div>
	   <div class="header-icons">
	   	 <h2 class="mystyle1"><font color="#fdbd10">ONLINE HOSTEL MANAGEMENT SYSTEM</font></h2>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav">
            	<!--<span class="menu"> <img src="images/icon.png" alt=""></span>-->	
				<ul class="res">
					<li><a href="room_info.php"><i class="glyphicon glyphicon-home"> </i>Room Information</a></li>
					<li><a href="add_room.php"><i class="glyphicon glyphicon-home"> </i>Add<br>Room</a></li>					
					<li><a class="active" href="update_room.php"><i class="glyphicon glyphicon-home"> </i>Update Room</a></li>
					<li><a href="del_room.php"><i class="glyphicon glyphicon-home"> </i>Delete Room</a></li>
					<li><a href="room_mem.php"><i class="glyphicon glyphicon-user"> </i>Room Members</a></li>
				</ul>
				<!-- script-for-menu -->
							 <!--<script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
			<!-- /script-for-menu -->
</div>		
</div>	
<!--banner end here-->
<div class="container">  
  <div class="row">
    <div class="row">
    <div class="col-md-6"><a href="admin_home.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>/ <span class="glyphicon glyphicon-user"></span> Room Management</div>	
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
	<div class="col-md-1"></div>
    <div class="col-md-1"><a href="logout.php" class="btn btn-link" role="button"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>    
  </div>    
  </div>
</div>
<!--contact start here-->
<div class="contact" id="contact">
			<div class="container">			
				<div class="contact-top">					
					<h3>Update Room</h3>					
				</div>
				<form action="#" method="post">
				<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->
						</div>
						<div class="col-md-4 contact-us">
							<font size="5" face="impact">Room No.:</font><br>
							<select id="room_no" name="room_no">
								<option value="select" selected>-- Select --</option>
								
							<?php
							
							//room nos.
							
							include("connec.php");	//database parameters

							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 

							$sql = "SELECT room_no FROM room";
							$result = $conn->query($sql);
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo '<option value="'.$row['room_no'].'">'.$row['room_no'].'</option>';
								}	
								
							} else {
								//echo "";
							}
							$conn->close();
							?>
								
							</select>
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
				</div>
				<center>
					<div class="send">
						<input type="submit" id="submit" name="submit" value="Submit">
					</div>
					</center>
				</form>
				
			<!-- room search starts -->
			<?php
			if(isset($_POST['submit']) && $_POST['room_no']!="select") {
				
				include("connec.php");	//database parameters

				$room_no=$_POST["room_no"];				

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}

				$sql = "SELECT * FROM room where room_no='$room_no'";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {    
					// output data of each row
					while($row = $result->fetch_assoc()) {
						$room_no=$row["room_no"];
						$building=$row["building"];
						$beds_taken=$row["beds_taken"];
						$total_beds=$row["total_beds"];						
					}	
				} else {
					//echo "Record not found";
				}

				$conn->close();
			}
			?>
			<!-- room search ends -->
				
				<br>
				<br>
				<br>
				<form action="update_room.php" method="post">					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							Room No.:<br>
							<input type="text" id="room_no" name="room_no" value="<?php if(isset($_POST['submit'])){ echo $room_no; } ?>" style="text-transform:uppercase">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>					
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Building:<br>
							<input type="text" id="building" name="building" value="<?php if(isset($_POST['submit'])){ echo $building; } ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>										
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!-- <input type="text" name="Name" placeholder="Name">-->							
						</div>
						<div class="col-md-4 contact-us">
							Total Beds:<br>
							<input type="number" id="total_beds" name="total_beds" value="<?php if(isset($_POST['submit'])){ echo $total_beds; } ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Email" placeholder="Email">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="contact-grid">
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="URL" placeholder="URL">-->
						</div>
						<div class="col-md-4 contact-us">
							Beds Taken:<br>
							<input type="number" id="beds_taken" name="beds_taken" value="<?php if(isset($_POST['submit'])){ echo $beds_taken; } ?>">
						</div>
						<div class="col-md-4 contact-us">
							<!--<input type="text" name="Subject" placeholder="Subject">-->
						</div>
						<div class="clearfix"> </div>
					</div>
					<center>
					<div class="send">
						<input type="submit" id="update" name="update" value="Update">
					</div>
					</center>
				</form>				
			</div>			
		</div>
<!--contact end here-->

			<!-- update room starts -->
			<?php					
			if(isset($_POST['update'])) {
			
			include("connec.php");	//database parameters			
			
			$room_no=$_POST["room_no"];
			$building=$_POST["building"];
			$beds_taken=$_POST["beds_taken"];
			$total_beds=$_POST["total_beds"];
			
			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 

			$sql = "UPDATE room SET room_no='$room_no',building='$building',beds_taken=$beds_taken,total_beds='$total_beds' WHERE room_no='$room_no'";

			if ($conn->query($sql) === TRUE) {
				echo "<p align='center'>room updated successfully.....</p>";
			} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
			
			}
			?>
			<!-- update room ends -->	

<hr>
<!--copy rights start here-->
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <?php
				include("footer.html");
			?>
    	 </div>
    </div>
</div>
<!--copy right end here-->
</body>
</html>